export interface AcDbDwgVersionEntry {
    name: string;
    value: number;
}
/**
 * Represents a DWG file format version.
 *
 * Instances can be constructed from either a known DWG version name
 * (e.g. 'AC1032') or its numeric value counterpart.
 */
export declare class AcDbDwgVersion {
    /**
     * DWG version name as defined in `AcDbDwgVersionEntry.name`.
     */
    name: string;
    /**
     * Numeric DWG version value as defined in `AcDbDwgVersionEntry.value`.
     */
    value: number;
    /**
     * Create a DWG version from a version name or numeric value.
     *
     * If a string is provided, it is treated as the version name and must
     * match one of the known entries. If a number is provided, it is treated
     * as the numeric version value.
     *
     * @param nameOrValue The DWG version name (e.g. 'AC1032') or the DWG version numeric value.
     * @throws Error if the provided name or value is not recognized.
     */
    constructor(nameOrValue: string | number);
}
//# sourceMappingURL=AcDbDwgVersion.d.ts.map