import { AcGePoint2d } from '@mlightcad/geometry-engine';
import { AcGiView } from '@mlightcad/graphic-interface';
import { AcDbSymbolTableRecord } from './AcDbSymbolTableRecord';
/**
 * Represents a viewport table record in AutoCAD.
 *
 * This class represents viewport arrangements in AutoCAD, which define how
 * the drawing is displayed in different areas of the screen or paper space.
 * Viewports can have their own zoom levels, pan positions, grid settings,
 * and other display properties.
 *
 * @example
 * ```typescript
 * const viewportRecord = new AcDbViewportTableRecord();
 * viewportRecord.name = '*Active';
 * viewportRecord.circleSides = 100;
 * viewportRecord.lowerLeftCorner = new AcGePoint2d(0, 0);
 * viewportRecord.upperRightCorner = new AcGePoint2d(1, 1);
 * ```
 */
export declare class AcDbViewportTableRecord extends AcDbSymbolTableRecord {
    /** Number of sides used for circle tessellation */
    private _circleSides;
    /** Center point of the viewport */
    private _center;
    /** Lower left corner of the viewport window */
    private _lowerLeftCorner;
    /** Upper right corner of the viewport window */
    private _upperRightCorner;
    /** Snap base point for the viewport */
    private _snapBase;
    /** Snap angle for the viewport */
    private _snapAngle;
    /** Snap spacing for the viewport */
    private _snapSpacing;
    /** Standard flags for the viewport */
    private _standardFlag;
    /** Grid spacing for the viewport */
    private _gridSpacing;
    /** Grid major spacing for the viewport */
    private _gridMajor;
    /** Background object ID for the viewport */
    private _backgroundObjectId?;
    /** Graphics system view configuration */
    private _gsView;
    /**
     * Creates a new AcDbViewportTableRecord instance.
     *
     * @example
     * ```typescript
     * const viewportRecord = new AcDbViewportTableRecord();
     * ```
     */
    constructor();
    /**
     * Gets or sets the circle zoom percent.
     *
     * This controls the number of sides to the tessellation used when displaying
     * curves. The value can be between 1 and 20000, with higher settings using
     * more sides in the curve tessellation.
     *
     * @returns The number of sides used for circle tessellation
     *
     * @example
     * ```typescript
     * const sides = viewportRecord.circleSides;
     * viewportRecord.circleSides = 200; // Higher quality circles
     * ```
     */
    get circleSides(): number;
    set circleSides(value: number);
    /**
     * Gets the center point of the viewport.
     *
     * @returns The center point of the viewport
     *
     * @example
     * ```typescript
     * const center = viewportRecord.center;
     * ```
     */
    get center(): AcGePoint2d;
    /**
     * Gets or sets the lower left corner of the viewport window.
     *
     * The X and Y values of this point are expressed as a value between (0.0, 0.0)
     * for the lower left corner of the AutoCAD graphics area and (1.0, 1.0) for
     * the upper right corner of the AutoCAD graphics area. For example, a lower
     * left corner value of (0.5, 0.0) indicates that the viewport's lower left
     * corner is along the bottom of the AutoCAD graphics area, midway between
     * the left and right edges of the graphics area.
     *
     * @returns The lower left corner point
     *
     * @example
     * ```typescript
     * const corner = viewportRecord.lowerLeftCorner;
     * viewportRecord.lowerLeftCorner = new AcGePoint2d(0.25, 0.25);
     * ```
     */
    get lowerLeftCorner(): AcGePoint2d;
    set lowerLeftCorner(value: AcGePoint2d);
    /**
     * The upper right corner of the viewport window. The X and Y values of this point are expressed as
     * a value between (0.0, 0.0) for the lower left corner of the AutoCAD graphics area and (1.0, 1.0)
     * for upper right corner of the AutoCAD graphics area. For example, an upper right corner value of
     * (0.5, 1.0) indicates that the viewport's upper right corner is along the top of the AutoCAD
     * graphics area, midway between the left and right edges of the graphics area.
     */
    get upperRightCorner(): AcGePoint2d;
    set upperRightCorner(value: AcGePoint2d);
    /**
     * The snap basepoint (in UCS coordinates) for the viewport table record.
     */
    get snapBase(): AcGePoint2d;
    set snapBase(value: AcGePoint2d);
    /**
     * The snap angle setting (in radians) for the viewport table record. The snap angle is measured
     * within the UCS XY plane, with zero being the UCS X axis and positive angles going counterclockwise
     * when looking down the UCS Z axis towards the UCS origin.
     */
    get snapAngle(): number;
    set snapAngle(value: number);
    /**
     * An AcGePoint2d in which the X value represents the X spacing of the snap grid and the Y value
     * represents the Y spacing of the snap grid. Both values are in drawing units.
     */
    get snapIncrements(): AcGePoint2d;
    set snapIncrements(value: AcGePoint2d);
    /**
     * The number of minor grid lines between each major grid line in the viewport.
     */
    get gridMajor(): number;
    set gridMajor(value: number);
    /**
     * An AcGePoint2d in which the X value represents the X spacing (in drawing units) of the grid and
     * the Y value represents the Y spacing of the grid.
     */
    get gridIncrements(): AcGePoint2d;
    set gridIncrements(value: AcGePoint2d);
    get standardFlag(): number;
    set standardFlag(value: number);
    get snapEnabled(): boolean;
    /**
     * The object dD of the new background for the view.
     */
    get backgroundObjectId(): string | undefined;
    set backgroundObjectId(value: string | undefined);
    /**
     * The AcGiView associated with this viewport table record
     */
    get gsView(): AcGiView;
}
//# sourceMappingURL=AcDbViewportTableRecord.d.ts.map