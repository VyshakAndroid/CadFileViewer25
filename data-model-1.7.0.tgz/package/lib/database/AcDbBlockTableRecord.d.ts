import { AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcDbObjectId } from '../base/AcDbObject';
import { AcDbEntity } from '../entity/AcDbEntity';
import { AcDbObjectIterator } from '../misc/AcDbObjectIterator';
import { AcDbSymbolTableRecord } from './AcDbSymbolTableRecord';
/**
 * Block table record that serves as a container for entities within drawing databases.
 *
 * Block table records (BTRs) are used to organize and group entities together.
 * There are two special BTRs that are always present in every database:
 * - *MODEL_SPACE: Contains entities in model space
 * - *PAPER_SPACE: Contains entities in paper space
 *
 * Each block table record has an origin point and can contain multiple entities.
 *
 * @example
 * ```typescript
 * const blockRecord = new AcDbBlockTableRecord();
 * blockRecord.name = 'MyBlock';
 * blockRecord.origin = new AcGePoint3d(0, 0, 0);
 * blockRecord.appendEntity(new AcDbLine());
 * ```
 */
export declare class AcDbBlockTableRecord extends AcDbSymbolTableRecord {
    /** Name constant for model space block table record */
    static MODEL_SPACE_NAME: string;
    /** Name prefix for paper space block table records */
    static PAPER_SPACE_NAME_PREFIX: string;
    /** The base point of the block in WCS coordinates */
    private _origin;
    /** The object id of the associated AcDbLayout object in the Layouts dictionary.*/
    private _layoutId;
    /** Map of entities indexed by their object IDs */
    private _entities;
    /**
     * Returns true if the specified name is the name of the model space block table record.
     *
     * Model space is the primary drawing area where most entities are created.
     *
     * @param name - The name of one block table record.
     * @returns True if the specified name is the name of the model space block table record.
     *
     * @example
     * ```typescript
     * if (AcDbBlockTableRecord.isModelSapceName('*Model_Space')) {
     *   console.log('This is the name of the model space block table record.');
     * }
     * ```
     */
    static isModelSapceName(name: string): boolean;
    /**
     * Returns true if the specified name is the name of a paper space block table record.
     *
     * Paper space is used for creating layouts for printing and plotting.
     *
     * @param name - The name of one block table record.
     * @returns True if the specified name is the name of a paper space block table record.
     *
     * @example
     * ```typescript
     * if (AcDbBlockTableRecord.isPaperSapceName('*Paper_Space1')) {
     *   console.log('This is the name of the paper space block table record.');
     * }
     * ```
     */
    static isPaperSapceName(name: string): boolean;
    /**
     * Creates a new AcDbBlockTableRecord instance.
     *
     * @example
     * ```typescript
     * const blockRecord = new AcDbBlockTableRecord();
     * ```
     */
    constructor();
    /**
     * Returns true if this is a model space block table record.
     *
     * Model space is the primary drawing area where most entities are created.
     *
     * @returns True if this is a model space block table record
     *
     * @example
     * ```typescript
     * if (blockRecord.isModelSapce) {
     *   console.log('This is model space');
     * }
     * ```
     */
    get isModelSapce(): boolean;
    /**
     * Returns true if this is a paper space block table record.
     *
     * Paper space is used for creating layouts for printing and plotting.
     *
     * @returns True if this is a paper space block table record
     *
     * @example
     * ```typescript
     * if (blockRecord.isPaperSapce) {
     *   console.log('This is paper space');
     * }
     * ```
     */
    get isPaperSapce(): boolean;
    /**
     * Gets or sets the base point of the block in WCS coordinates.
     *
     * This point is the origin of the MCS (Model Coordinate System), which is the
     * local WCS for the entities within the block table record.
     *
     * @returns The origin point of the block
     *
     * @example
     * ```typescript
     * const origin = blockRecord.origin;
     * blockRecord.origin = new AcGePoint3d(10, 20, 0);
     * ```
     */
    get origin(): AcGePoint3d;
    set origin(value: AcGePoint3d);
    /**
     * Gets or sets the object ID of the associated AcDbLayout object in the Layouts dictionary.
     *
     * This property links the block table record to its corresponding layout object,
     * which defines the viewport configuration and display settings for the block.
     * For model space blocks, this is typically empty, while paper space blocks
     * have a corresponding layout ID.
     *
     * @returns The object ID of the associated layout
     *
     * @example
     * ```typescript
     * const layoutId = blockRecord.layoutId;
     * blockRecord.layoutId = 'some-layout-object-id';
     * ```
     */
    get layoutId(): AcDbObjectId;
    set layoutId(value: AcDbObjectId);
    /**
     * Appends the specified entity or entities to this block table record.
     *
     * This method adds an entity to the block and sets up the necessary
     * relationships between the entity and the block table record.
     *
     * @param entity - The entity or entities to append to this block table record
     *
     * @example
     * ```typescript
     * const line = new AcDbLine();
     * blockRecord.appendEntity(line);
     * ```
     */
    appendEntity(entity: AcDbEntity | AcDbEntity[]): void;
    /**
     * Removes the specified entity or entities from this block table record.
     *
     * Notes:
     * Please call method AcDbEntity.erase to remove one entity instead of calling
     * this function.
     *
     * AutoCAD ObjectARX API doesn't provide such one method to remove entities
     * from the block table record. I guess it is done by friend class or function
     * feature in C++. However, there are no similar feature in TypeScript. So
     * we have to expose such one public method in AcDbBlockTableRecord.
     *
     * @param objectId - The object id or ids of entities to remove from this block table record
     * @returns — true if an entity in the block table record existed and has been removed,
     * or false if the entity does not exist.
     */
    removeEntity(objectId: AcDbObjectId | AcDbObjectId[]): boolean;
    /**
     * Creates an iterator object that can be used to iterate over the entities in the block table record.
     *
     * @returns An iterator object that can be used to iterate over the entities
     *
     * @example
     * ```typescript
     * const iterator = blockRecord.newIterator();
     * for (const entity of iterator) {
     *   console.log('Entity:', entity.type);
     * }
     * ```
     */
    newIterator(): AcDbObjectIterator<AcDbEntity>;
    /**
     * Searches for an entity in this block table record with the specified ID.
     *
     * @param id - The entity ID to search for
     * @returns The entity with the specified ID, or undefined if not found
     */
    getIdAt(id: AcDbObjectId): AcDbEntity | undefined;
}
//# sourceMappingURL=AcDbBlockTableRecord.d.ts.map