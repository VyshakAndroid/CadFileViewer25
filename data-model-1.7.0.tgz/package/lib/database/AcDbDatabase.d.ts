import { AcCmColor, AcCmEventManager } from '@mlightcad/common';
import { AcDbObject, AcDbObjectId } from '../base';
import { AcDbConverterType } from './AcDbDatabaseConverterManager';
import { AcDbEntity } from '../entity';
import { AcDbDictionary, AcDbLayoutDictionary, AcDbRasterImageDef, AcDbXrecord } from '../object';
import { AcDbBlockTable } from './AcDbBlockTable';
import { AcDbConversionStage, AcDbStageStatus } from './AcDbDatabaseConverter';
import { AcDbDimStyleTable } from './AcDbDimStyleTable';
import { AcDbLayerTable } from './AcDbLayerTable';
import { AcDbLayerTableRecord, AcDbLayerTableRecordAttrs } from './AcDbLayerTableRecord';
import { AcDbLinetypeTable } from './AcDbLinetypeTable';
import { AcDbTextStyleTable } from './AcDbTextStyleTable';
import { AcDbViewportTable } from './AcDbViewportTable';
import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcDbDwgVersion } from './AcDbDwgVersion';
import { AcGiLineWeight } from '@mlightcad/graphic-interface';
import { AcDbRegAppTable } from './AcDbRegAppTable';
/**
 * Event arguments for object events in the dictionary.
 */
export interface AcDbDictObjectEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The object (or objects) involved in the event */
    object: AcDbObject | AcDbObject[];
    /** The key name of the object */
    key: string;
}
/**
 * Event arguments for entity-related events.
 */
export interface AcDbEntityEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The entity (or entities) involved in the event */
    entity: AcDbEntity | AcDbEntity[];
}
/**
 * Event arguments for layer-related events.
 */
export interface AcDbLayerEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The layer involved in the event */
    layer: AcDbLayerTableRecord;
}
/**
 * Event arguments for layer modification events.
 */
export interface AcDbLayerModifiedEventArgs extends AcDbLayerEventArgs {
    /** The changes made to the layer */
    changes: Partial<AcDbLayerTableRecordAttrs>;
}
/**
 * The stage of opening one drawing file
 */
export type AcDbOpenFileStage = 'FETCH_FILE' | 'CONVERSION';
/**
 * Event arguments for progress events during database operations.
 */
export interface AcDbProgressdEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The progress percentage (0-100) */
    percentage: number;
    /** The current stage of opening one drawing file */
    stage: AcDbOpenFileStage;
    /** The current sub stage */
    subStage?: AcDbConversionStage;
    /** The status of the current sub stage */
    subStageStatus: AcDbStageStatus;
    /**
     * Store data associated with the current sub stage. Its meaning of different sub stages
     * are as follows.
     * - 'PARSE' stage: statistics of parsing task
     * - 'FONT' stage: fonts needed by this drawing
     *
     * Note: For now, 'PARSE' and 'FONT' sub stages use this field only.
     */
    data?: unknown;
}
/**
 * Event arguments for header system variable changes.
 */
export interface AcDbHeaderSysVarEventArgs {
    /** The database that triggered the event */
    database: AcDbDatabase;
    /** The name of the system variable that changed */
    name: string;
}
/**
 * Font information structure.
 *
 * Contains information about a font including its name, file path,
 * type, and URL for loading.
 */
export interface AcDbFontInfo {
    /** Array of font names/aliases */
    name: string[];
    /** Font file name */
    file: string;
    /** Font type (mesh or shx) */
    type: 'mesh' | 'shx';
    /** URL for loading the font */
    url: string;
}
/**
 * Interface for loading fonts when opening a document.
 *
 * Applications should implement this interface to provide font loading
 * functionality when opening drawing databases that contain text entities.
 */
export interface AcDbFontLoader {
    /**
     * Loads the specified fonts.
     *
     * @param fontNames - Array of font names to load
     * @returns Promise that resolves when fonts are loaded
     *
     * @example
     * ```typescript
     * const fontLoader: AcDbFontLoader = {
     *   async load(fontNames: string[]) {
     *     // Load fonts implementation
     *   },
     *   async getAvaiableFonts() {
     *     return [];
     *   }
     * };
     * ```
     */
    load(fontNames: string[]): Promise<void>;
    /**
     * Gets all available fonts.
     *
     * @returns Promise that resolves to an array of available font information
     *
     * @example
     * ```typescript
     * const fonts = await fontLoader.getAvaiableFonts();
     * console.log('Available fonts:', fonts);
     * ```
     */
    getAvaiableFonts(): Promise<AcDbFontInfo[]>;
}
/**
 * Options for reading a drawing database.
 *
 * These options control how a drawing database is opened and processed.
 */
export interface AcDbOpenDatabaseOptions {
    /**
     * Opens the drawing database in read-only mode.
     *
     * When true, the database will be opened in read-only mode, preventing
     * any modifications to the database content.
     */
    readOnly?: boolean;
    /**
     * Loader used to load fonts used in the drawing database.
     *
     * This loader will be used to load any fonts referenced by text entities
     * in the drawing database.
     */
    fontLoader?: AcDbFontLoader;
    /**
     * The minimum number of items in one chunk.
     *
     * If this value is greater than the total number of entities in the
     * drawing database, the total number is used. This controls how the
     * database processing is broken into chunks for better performance.
     */
    minimumChunkSize?: number;
}
/**
 * Interface defining the tables available in a drawing database.
 *
 * This interface provides access to all the symbol tables in the database,
 * including block table, dimension style table, linetype table, text style table,
 * layer table, and viewport table.
 */
export interface AcDbTables {
    /** Registered application name table */
    readonly appIdTable: AcDbRegAppTable;
    /** Block table containing block definitions */
    readonly blockTable: AcDbBlockTable;
    /** Dimension style table containing dimension style definitions */
    readonly dimStyleTable: AcDbDimStyleTable;
    /** Linetype table containing linetype definitions */
    readonly linetypeTable: AcDbLinetypeTable;
    /** Text style table containing text style definitions */
    readonly textStyleTable: AcDbTextStyleTable;
    /** Layer table containing layer definitions */
    readonly layerTable: AcDbLayerTable;
    /** Viewport table containing viewport definitions */
    readonly viewportTable: AcDbViewportTable;
}
/**
 * Options used to specify default data to create
 */
export interface AcDbCreateDefaultDataOptions {
    layer?: boolean;
    lineType?: boolean;
    textStyle?: boolean;
    dimStyle?: boolean;
    layout?: boolean;
}
/**
 * The AcDbDatabase class represents an AutoCAD drawing file.
 *
 * Each AcDbDatabase object contains the various header variables, symbol tables,
 * table records, entities, and objects that make up the drawing. The AcDbDatabase
 * class has member functions to allow access to all the symbol tables, to read
 * and write to DWG files, to get or set database defaults, to execute various
 * database-level operations, and to get or set all header variables.
 *
 * @example
 * ```typescript
 * const database = new AcDbDatabase();
 * await database.read(dxfData, { readOnly: true });
 * const entities = database.tables.blockTable.modelSpace.entities;
 * ```
 */
export declare class AcDbDatabase extends AcDbObject {
    /** Version of the database */
    private _version;
    /** Angle base for the database */
    private _angBase;
    /** Angle direction for the database */
    private _angDir;
    /** Angle units for the database */
    private _aunits;
    /** Current entity color */
    private _cecolor;
    /** Current entity linetype scale */
    private _celtscale;
    /** Current entity line weight value */
    private _celweight;
    /** Current layer for the database */
    private _clayer;
    /** The extents of current Model Space */
    private _extents;
    /** Insertion units for the database */
    private _insunits;
    /** Global linetype scale */
    private _ltscale;
    /** Point display mode */
    private _pdmode;
    /** Point display size */
    private _pdsize;
    /** Tables in the database */
    private _tables;
    /** Nongraphical objects in the database */
    private _objects;
    /** Current space (model space or paper space) */
    private _currentSpace?;
    /**
     * Events that can be triggered by the database.
     *
     * These events allow applications to respond to various database operations
     * such as entity modifications, layer changes, and progress updates.
     */
    readonly events: {
        /** Fired when an object is set to the dictionary */
        dictObjetSet: AcCmEventManager<AcDbDictObjectEventArgs>;
        /** Fired when an object in the dictionary is removed */
        dictObjectErased: AcCmEventManager<AcDbDictObjectEventArgs>;
        /** Fired when an entity is appended to the database */
        entityAppended: AcCmEventManager<AcDbEntityEventArgs>;
        /** Fired when an entity is modified in the database */
        entityModified: AcCmEventManager<AcDbEntityEventArgs>;
        /** Fired when an entity is erased from the database */
        entityErased: AcCmEventManager<AcDbEntityEventArgs>;
        /** Fired when a layer is appended to the database */
        layerAppended: AcCmEventManager<AcDbLayerEventArgs>;
        /** Fired when a layer is modified in the database */
        layerModified: AcCmEventManager<AcDbLayerModifiedEventArgs>;
        /** Fired when a layer is erased from the database */
        layerErased: AcCmEventManager<AcDbLayerEventArgs>;
        /** Fired during database opening operations to report progress */
        openProgress: AcCmEventManager<AcDbProgressdEventArgs>;
        /** Fired when a header system variable is changed */
        headerSysVarChanged: AcCmEventManager<AcDbHeaderSysVarEventArgs>;
    };
    static MLIGHTCAD_APPID: string;
    /**
     * Creates a new AcDbDatabase instance.
     */
    constructor();
    /**
     * Gets all tables in this drawing database.
     *
     * @returns Object containing all the symbol tables in the database
     *
     * @example
     * ```typescript
     * const tables = database.tables;
     * const layers = tables.layerTable;
     * const blocks = tables.blockTable;
     * ```
     */
    get tables(): AcDbTables;
    /**
     * Gets all nongraphical objects in this drawing database.
     *
     * @returns Object containing all nongraphical objects in the database
     *
     * @example
     * ```typescript
     * const objects = database.objects;
     * const layout = objects.layout;
     * ```
     */
    get objects(): {
        readonly dictionary: AcDbDictionary<AcDbDictionary>;
        readonly imageDefinition: AcDbDictionary<AcDbRasterImageDef>;
        readonly layout: AcDbLayoutDictionary;
        readonly xrecord: AcDbDictionary<AcDbXrecord>;
    };
    /**
     * Gets the object ID of the AcDbBlockTableRecord of the current space.
     *
     * The current space can be either model space or paper space.
     *
     * @returns The object ID of the current space
     *
     * @example
     * ```typescript
     * const currentSpaceId = database.currentSpaceId;
     * ```
     */
    get currentSpaceId(): AcDbObjectId;
    /**
     * Sets the current space by object ID.
     *
     * @param value - The object ID of the block table record to set as current space
     * @throws {Error} When the specified block table record ID doesn't exist
     *
     * @example
     * ```typescript
     * database.currentSpaceId = 'some-block-record-id';
     * ```
     */
    set currentSpaceId(value: AcDbObjectId);
    /**
     * Gets the angle units for the database.
     *
     * This is the current AUNITS value for the database.
     *
     * @returns The angle units value
     *
     * @example
     * ```typescript
     * const angleUnits = database.aunits;
     * ```
     */
    get aunits(): number;
    /**
     * Sets the angle units for the database.
     *
     * @param value - The new angle units value
     *
     * @example
     * ```typescript
     * database.aunits = AcDbAngleUnits.DecimalDegrees;
     * ```
     */
    set aunits(value: number);
    /**
     * Gets the version of the database.
     *
     * @returns The version of the database
     *
     */
    get version(): AcDbDwgVersion;
    /**
     * Sets the version of the database.
     *
     * @param value - The version value of the database
     */
    set version(value: string | number);
    /**
     * Gets the drawing-units value for automatic scaling of blocks, images, or xrefs.
     *
     * This is the current INSUNITS value for the database.
     *
     * @returns The insertion units value
     *
     * @example
     * ```typescript
     * const insertionUnits = database.insunits;
     * ```
     */
    get insunits(): number;
    /**
     * Sets the drawing-units value for automatic scaling.
     *
     * @param value - The new insertion units value
     *
     * @example
     * ```typescript
     * database.insunits = AcDbUnitsValue.Millimeters;
     * ```
     */
    set insunits(value: number);
    /**
     * Gets the line type scale factor.
     *
     * @returns The line type scale factor
     *
     * @example
     * ```typescript
     * const lineTypeScale = database.ltscale;
     * ```
     */
    get ltscale(): number;
    /**
     * Sets the line type scale factor.
     *
     * @param value - The new line type scale factor
     *
     * @example
     * ```typescript
     * database.ltscale = 2.0;
     * ```
     */
    set ltscale(value: number);
    /**
     * Gets the color of new objects as they are created.
     *
     * @returns The current entity color
     *
     * @example
     * ```typescript
     * const currentColor = database.cecolor;
     * ```
     */
    get cecolor(): AcCmColor;
    /**
     * Sets the color of new objects as they are created.
     *
     * @param value - The new current entity color
     *
     * @example
     * ```typescript
     * database.cecolor = new AcCmColor(0xFF0000);
     * ```
     */
    set cecolor(value: AcCmColor);
    /**
     * The line type scaling for new objects relative to the ltscale setting. A line created with
     * celtscale = 2 in a drawing with ltscale set to 0.5 would appear the same as a line created
     * with celtscale = 1 in a drawing with ltscale = 1.
     */
    get celtscale(): number;
    set celtscale(value: number);
    /**
     * The layer of new objects as they are created.
     */
    get celweight(): AcGiLineWeight;
    set celweight(value: AcGiLineWeight);
    /**
     * The layer of new objects as they are created.
     */
    get clayer(): string;
    set clayer(value: string);
    /**
     * The zero (0) base angle with respect to the current UCS in radians.
     */
    get angBase(): number;
    set angBase(value: number);
    /**
     * The direction of positive angles.
     * - 0: Counterclockwise
     * - 1: Clockwise
     */
    get angDir(): number;
    set angDir(value: number);
    /**
     * The current Model Space EXTMAX value
     */
    get extmax(): AcGePoint3d;
    set extmax(value: AcGePoint3dLike);
    /**
     * The current Model Space EXTMIN value
     */
    get extmin(): AcGePoint3d;
    set extmin(value: AcGePoint3dLike);
    /**
     * The extents of current Model Space
     */
    get extents(): AcGeBox3d;
    /**
     * Point display mode. Please get more details on value of this property from [this page](https://help.autodesk.com/view/ACDLT/2022/ENU/?guid=GUID-82F9BB52-D026-4D6A-ABA6-BF29641F459B).
     */
    get pdmode(): number;
    set pdmode(value: number);
    /**
     * Point display size.
     * - 0: Creates a point at 5 percent of the drawing area height
     * - > 0: Specifies an absolute size
     * - < 0: Specifies a percentage of the viewport size
     */
    get pdsize(): number;
    set pdsize(value: number);
    /**
     * Reads drawing data from a string or ArrayBuffer.
     *
     * This method parses the provided data and populates the database with
     * the resulting entities, tables, and objects. The method supports
     * both DXF and DWG file formats.
     *
     * @param data - The drawing data as a string or ArrayBuffer
     *   - For DXF files: Pass a string containing the DXF content
     *   - For DWG files: Pass an ArrayBuffer instance containing the binary DWG data
     * @param options - Options for reading the database
     * @param fileType - The type of file being read (defaults to DXF)
     *
     * @example
     * ```typescript
     * // Reading a DXF file (string)
     * const database = new AcDbDatabase();
     * await database.read(dxfString, { readOnly: true }, AcDbFileType.DXF);
     *
     * // Reading a DWG file (ArrayBuffer)
     * const database = new AcDbDatabase();
     * await database.read(dwgArrayBuffer, { readOnly: true }, AcDbFileType.DWG);
     * ```
     */
    read(data: ArrayBuffer, options: AcDbOpenDatabaseOptions, fileType?: AcDbConverterType): Promise<void>;
    /**
     * Read AutoCAD DXF or DWG drawing specified by the URL into the database object.
     * The method automatically detects the file type based on the URL extension:
     * - .dxf files are read as text using readAsText()
     * - .dwg files are read as binary data using readAsArrayBuffer()
     * @param url Input the URL linked to one AutoCAD DXF or DWG file
     * @param options Input options to read drawing data
     */
    openUri(url: string, options: AcDbOpenDatabaseOptions): Promise<void>;
    /**
     * Triggers xxxAppended events with data in the database to redraw the associated viewer.
     */
    regen(): Promise<void>;
    /**
     * Create default layer, line type, dimension type, text style and layout.
     * @param - Options to specify data to create
     */
    createDefaultData(options?: AcDbCreateDefaultDataOptions): void;
    /**
     * Clears all data from the database.
     *
     * This method removes all entities, tables, and objects from the database,
     * effectively resetting it to an empty state.
     *
     * @example
     * ```typescript
     * database.clear();
     * ```
     */
    private clear;
    /**
     * Triggers a header system variable changed event.
     *
     * This method is called internally when header system variables
     * are modified to notify listeners of the change.
     *
     * @param sysVarName - The name of the system variable that changed
     *
     * @example
     * ```typescript
     * database.triggerHeaderSysVarChangedEvent('aunits');
     * ```
     */
    private triggerHeaderSysVarChangedEvent;
    /**
     * Extracts the file name from a URI.
     *
     * @param uri - The URI to extract the file name from
     * @returns The extracted file name, or empty string if extraction fails
     * @private
     */
    private getFileNameFromUri;
}
//# sourceMappingURL=AcDbDatabase.d.ts.map