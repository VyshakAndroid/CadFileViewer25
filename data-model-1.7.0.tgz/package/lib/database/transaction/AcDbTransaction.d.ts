import { AcDbObject, AcDbObjectId, AcDbOpenMode } from '../../base';
/**
 * Represents a single database transaction.
 *
 * A transaction records the original state of opened objects so that
 * changes can be committed or rolled back.
 *
 * This class is normally not instantiated directly by users.
 */
export declare class AcDbTransaction {
    /** Objects opened in this transaction */
    private readonly openedObjects;
    /** Snapshots of objects before modification */
    private readonly originalStates;
    /**
     * Records an object opening.
     *
     * @param objectId - Object identifier
     * @param mode - Open mode
     * @param openErased - Whether erased objects are allowed
     */
    getObject<T extends AcDbObject>(objectId: AcDbObjectId, mode: AcDbOpenMode, openErased?: boolean): T | undefined;
    /**
     * Commits this transaction.
     * After commit, rollback data is discarded.
     */
    commit(): void;
    /**
     * Aborts this transaction and restores all modified objects.
     */
    abort(): void;
    /**
     * Internal object lookup hook.
     *
     * You should connect this to your database or object table.
     */
    protected lookupObject<T extends AcDbObject>(objectId: AcDbObjectId, _openErased: boolean): T;
}
//# sourceMappingURL=AcDbTransaction.d.ts.map