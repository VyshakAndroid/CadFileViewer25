import { AcCmTaskError } from '@mlightcad/common';
import { AcDbDatabase } from './AcDbDatabase';
/**
 * Represents the different stages of DXF/DWG file conversion.
 *
 * These stages define the order and types of operations performed
 * during the conversion of a DXF or DWG file into an AcDbDatabase.
 */
export type AcDbConversionStage = 
/**
 * Start DXF/DWG file conversion
 */
'START'
/**
 * Parsing DXF/DWG file
 */
 | 'PARSE'
/**
 * Downloading font files
 */
 | 'FONT'
/**
 * Converting line types
 */
 | 'LTYPE'
/**
 * Converting text styles
 */
 | 'STYLE'
/**
 * Converting dimension styles
 */
 | 'DIMSTYLE'
/**
 * Converting layers
 */
 | 'LAYER'
/**
 * Converting viewports
 */
 | 'VPORT'
/**
 * Converting block table record
 */
 | 'BLOCK_RECORD'
/**
 * Converting file header
 */
 | 'HEADER'
/**
 * Converting blocks
 */
 | 'BLOCK'
/**
 * Converting entities in model space
 */
 | 'ENTITY'
/**
 * Converting objects such as nod
 */
 | 'OBJECT'
/**
 * Finish file conversion
 */
 | 'END';
/**
 * Represents the status of a stage.
 */
export type AcDbStageStatus = 'START' | 'END' | 'IN-PROGRESS' | 'ERROR';
/**
 * Callback function to update progress when parsing one file.
 *
 * This callback is called during the conversion process to provide
 * progress updates and stage information.
 *
 * @param percentage - Finish percentage (0-100)
 * @param stage - Name of the current stage
 * @param stageStatus - Status of the current stage
 * @param data - Store data associated with the current stage. Its meaning varies by stage:
 *   - 'FONT' stage: fonts needed by this drawing
 *
 * @example
 * ```typescript
 * const progressCallback: AcDbConversionProgressCallback = async (
 *   percentage,
 *   stage,
 *   stageStatus,
 *   data
 * ) => {
 *   console.log(`Progress: ${percentage}% - Stage: ${stage} - Status: ${stageStatus}`);
 *   if (stage === 'FONT' && data) {
 *     console.log('Fonts needed:', data);
 *   }
 * };
 * ```
 */
export type AcDbConversionProgressCallback = (
/**
 * Finish percentage
 */
percentage: number, 
/**
 * Name of the current stage.
 */
stage: AcDbConversionStage, 
/**
 * Status of the current stage.
 */
stageStatus: AcDbStageStatus, 
/**
 * Store data associated with the current stage. Its meaning of different stages are as follows.
 * - 'PARSE' stage: statistics of parsing task
 * - 'FONT' stage: fonts needed by this drawing
 *
 * Note: For now, 'PARSE' and 'FONT' stages use this field only.
 */
data?: unknown, 
/**
 * Represents an error that occurred during task execution in the scheduler.
 */
error?: AcCmTaskError) => Promise<void>;
/**
 * Statistics of parsing task
 */
export interface AcDbParsingTaskStats {
    /**
     * The number of unknown types of entities (custom entities or entities not supported
     * by parser) in one drawing to parse
     */
    unknownEntityCount: number;
}
/**
 * Interface defining type of return value of parsing task.
 */
export interface AcDbParsingTaskResult<TModel> {
    model: TModel | undefined;
    data: AcDbParsingTaskStats;
}
/**
 * Interface defining performance data for database conversion.
 */
export interface AcDbConvertDatabasePerformanceData {
    [key: string]: number;
    total: number;
}
/**
 * Configuration options for database converters.
 *
 * This interface defines the configuration parameters that can be passed
 * to database converters to customize their behavior during the conversion
 * process.
 */
export interface AcDbDatabaseConverterConfig {
    /**
     * Optional URL for web worker scripts used in the conversion process.
     *
     * When provided, this URL points to a web worker script that can be used
     * for offloading computationally intensive parsing tasks to a background
     * thread, improving performance and preventing UI blocking.
     *
     * @example
     * ```typescript
     * const config: AcDbDatabaseConverterConfig = {
     *   parserWorkerUrl: '/assets/dxf-parser-worker.js'
     * };
     * ```
     */
    parserWorkerUrl?: string | URL;
    /**
     * Whether to use web workers for computationally intensive tasks.
     *
     * When set to `true`, the converter will attempt to use web workers
     * for computationally intensive tasks, which can improve performance
     * by offloading work to background threads and preventing UI blocking.
     *
     * When set to `false`, all computationally intensive operations will be
     * performed on the main thread.
     *
     * @default false
     *
     * @example
     * ```typescript
     * const config: AcDbDatabaseConverterConfig = {
     *   useWorker: true,
     *   parserWorkerUrl: '/assets/dxf-parser-worker.js'
     * };
     * ```
     */
    useWorker?: boolean;
    /**
     * Whether to convert entities grouped by type.
     *
     * When set to `true`, the converter will process entities one type
     * at a time (e.g., all lines, then all circles, then all polylines),
     * which can help optimize rendering performance or simplify debugging by
     * handling each entity type in isolation.
     *
     * When set to `false`, entities are converted in the order they
     * appear in the source file.
     *
     * @default false
     *
     * @example
     * ```typescript
     * const config: AcDbDatabaseConverterConfig = {
     *   convertByEntityType: true
     * };
     * ```
     */
    convertByEntityType?: boolean;
}
/**
 * Abstract base class for database converters.
 *
 * This class provides the foundation for converting various file formats
 * (such as DXF, DWG) into AcDbDatabase objects. It handles the conversion
 * process in stages and provides progress tracking capabilities.
 *
 * @template TModel - The type of the parsed model data
 *
 * @example
 * ```typescript
 * class MyConverter extends AcDbDatabaseConverter<MyModel> {
 *   protected parse(data: string | ArrayBuffer): MyModel {
 *     // Implementation for parsing data
 *   }
 *
 *   ......
 *
 *   protected processEntities(model: MyModel, db: AcDbDatabase) {
 *     // Implementation for processing entities
 *   }
 * }
 * ```
 */
export declare abstract class AcDbDatabaseConverter<TModel = unknown> {
    /** Optional progress callback for tracking conversion progress */
    progress?: AcDbConversionProgressCallback;
    /** Configuration for the converter */
    readonly config: AcDbDatabaseConverterConfig;
    /**
     * Creates a new instance of the database converter.
     *
     * @param config - Configuration options for the converter. This includes settings
     *                 such as worker URL for web workers used in the conversion process.
     *                 If not provided, an empty configuration object will be used.
     *
     * @example
     * ```typescript
     * // Create converter with default configuration
     * const converter = new AcDbDxfConverter();
     *
     * // Create converter with custom worker URL
     * const converter = new AcDbDxfConverter({
     *   parserWorkerUrl: '/assets/dxf-parser-worker.js'
     * });
     * ```
     */
    constructor(config?: AcDbDatabaseConverterConfig);
    /**
     * Reads and converts data into an AcDbDatabase.
     *
     * This method orchestrates the entire conversion process, including
     * parsing, processing various components (fonts, linetypes, styles, etc.),
     * and building the final database.
     *
     * @param data - The input data to convert
     * @param db - The database to populate with converted data
     * @param minimumChunkSize - Minimum chunk size for batch processing
     * @param progress - Optional progress callback
     * @returns Promise that resolves when conversion is complete
     *
     */
    read(data: ArrayBuffer, db: AcDbDatabase, minimumChunkSize: number, progress?: AcDbConversionProgressCallback): Promise<void>;
    protected onError(error: AcCmTaskError): boolean;
    protected onFinished(): void;
    protected parse(_data: ArrayBuffer, _workerUrl?: string): Promise<AcDbParsingTaskResult<TModel>>;
    protected getFonts(_model: TModel): string[];
    protected processLineTypes(_model: TModel, _db: AcDbDatabase): void;
    protected processTextStyles(_model: TModel, _db: AcDbDatabase): void;
    protected processDimStyles(_model: TModel, _db: AcDbDatabase): void;
    protected processLayers(_model: TModel, _db: AcDbDatabase): void;
    protected processViewports(_model: TModel, _db: AcDbDatabase): void;
    protected processHeader(_model: TModel, _db: AcDbDatabase): void;
    protected processBlockTables(_model: TModel, _db: AcDbDatabase): void;
    protected processObjects(_model: TModel, _db: AcDbDatabase): void;
    protected processBlocks(_model: TModel, _db: AcDbDatabase): void;
    protected processEntities(_model: TModel, _db: AcDbDatabase, _minimumChunkSize: number, _percentage: {
        value: number;
    }, _progress?: AcDbConversionProgressCallback): void;
}
//# sourceMappingURL=AcDbDatabaseConverter.d.ts.map