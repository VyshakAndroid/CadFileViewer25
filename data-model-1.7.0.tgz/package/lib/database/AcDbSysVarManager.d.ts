import { AcCmColor, AcCmEventManager } from '@mlightcad/common';
import { AcGePointLike } from '@mlightcad/geometry-engine';
import { AcDbDatabase } from 'database';
/**
 * Supported AutoCAD system variable data type name.
 */
export type AcDbSysVarTypeName = 'string' | 'color' | 'number' | 'boolean' | 'point' | 'unknown';
/**
 * Supported AutoCAD system variable data type name.
 */
export type AcDbSysVarType = string | number | boolean | AcGePointLike | AcCmColor;
/**
 * Definition for a system variable in our registry.
 */
export interface AcDbSysVarDescriptor {
    /** System variable name, e.g., "CLAYER" */
    name: string;
    /** Expected variable type */
    type: AcDbSysVarTypeName;
    /** The flag to indicate whether it is one database-resident variable. */
    isDbVar: boolean;
    /** Optional description (documentation) */
    description?: string;
    /** Optional default value */
    defaultValue?: AcDbSysVarType;
}
/**
 * Event arguments for system variable related events.
 */
export interface AcDbSysVarEventArgs {
    /** The system variable name */
    name: string;
    /** The new value of system variable */
    newVal: AcDbSysVarType;
    /** The old value of system variable */
    oldVal?: AcDbSysVarType;
}
/**
 * Main manager responsible for:
 * - registry of known system variables
 * - caching values
 * - invoking backend getVar/setVar
 * - dispatching sysvar change events
 */
export declare class AcDbSysVarManager {
    private static _instance;
    /** Singleton accessor */
    static instance(): AcDbSysVarManager;
    /** Registered system variable metadata */
    private registry;
    /** Cached current values for non-database-resident variables. */
    private cache;
    /** System variable related events */
    readonly events: {
        /**
         * Fired after a system variable is changed directly through the SETVAR command or
         * by entering the variable name at the command line.
         */
        sysVarChanged: AcCmEventManager<AcDbSysVarEventArgs>;
    };
    private constructor();
    /**
     * Register one system variable metadata entry.
     */
    registerVar(desc: AcDbSysVarDescriptor): void;
    /**
     * Register many system variables.
     */
    registerMany(vars: AcDbSysVarDescriptor[]): void;
    /**
     * Get system variable value.
     */
    getVar(name: string, db: AcDbDatabase): AcDbSysVarType | undefined;
    /**
     * Set system variable value.
     */
    setVar(name: string, value: AcDbSysVarType, db: AcDbDatabase): void;
    /**
     * Get system variable metadata descriptor (if registered).
     */
    getDescriptor(name: string): AcDbSysVarDescriptor | undefined;
    /**
     * Get all registered system variable descriptors.
     */
    getAllDescriptors(): AcDbSysVarDescriptor[];
    /**
     * Parse one string as one boolean value with case-insensitive by ignoring extra spaces
     * - "true" / "false"
     * - "t" / "f"
     * - "1" / "0"
     * - "yes" / "no"
     * - "y" / "n"
     * @param value - One string
     * @returns - The parsed boolean value
     */
    private parseBoolean;
}
//# sourceMappingURL=AcDbSysVarManager.d.ts.map