import { AcDbSymbolTableRecord } from './AcDbSymbolTableRecord';
/**
 * Represents records in the AcDbRegAppTable (known as the APPID symbol table in AutoCAD and DXF).
 * Each of these records represents an application ID used to identify a group of Extended Entity
 * Data attached to objects in the drawing database.
 */
export declare class AcDbRegAppTableRecord extends AcDbSymbolTableRecord {
    constructor(name: string);
}
//# sourceMappingURL=AcDbRegAppTableRecord.d.ts.map