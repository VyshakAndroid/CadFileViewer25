import { AcDbDatabase } from '../database';
export declare class AcDbDataGenerator {
    readonly db: AcDbDatabase;
    constructor(db: AcDbDatabase);
    createDefaultLayer(): void;
    createDefaultLineType(): void;
    createDefaultTextStyle(): void;
    createDefaultDimStyle(): void;
    createDefaultLayout(): void;
    createArrowBlock(): void;
}
//# sourceMappingURL=AcDbDataGenerator.d.ts.map