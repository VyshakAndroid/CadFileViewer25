import { AcGeMatrix3d, AcGeVector3d } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbBlockTableRecord } from '../database';
/**
 * Internal class used to cache rendered results to avoid duplicated rendering.
 *
 * This class can be used to improve performance when rendering block references.
 * Because different colors will result in different materials, the block name and
 * color are used together to create the cache key.
 *
 * @internal
 *
 * @example
 * ```typescript
 * const cache = AcDbRenderingCache.instance;
 * const key = cache.createKey('MyBlock', 0xFF0000);
 * const renderedEntity = cache.draw(renderer, blockRecord, 0xFF0000);
 * ```
 */
export declare class AcDbRenderingCache {
    /** Map of cached rendering results indexed by key */
    private _blocks;
    /** Singleton instance of the cache */
    private static _instance?;
    /**
     * Gets the singleton instance of the rendering cache.
     *
     * @returns The singleton instance of AcDbRenderingCache
     *
     * @example
     * ```typescript
     * const cache = AcDbRenderingCache.instance;
     * ```
     */
    static get instance(): AcDbRenderingCache;
    /**
     * Creates a new AcDbRenderingCache instance.
     *
     * @example
     * ```typescript
     * const cache = new AcDbRenderingCache();
     * ```
     */
    constructor();
    /**
     * Creates a cache key by combining the block name and color.
     *
     * @param name - The block name
     * @param color - The color value
     * @returns A unique key for the cache entry
     *
     * @example
     * ```typescript
     * const key = cache.createKey('MyBlock', 0xFF0000);
     * // Returns: "MyBlock_16711680"
     * ```
     */
    createKey(name: string, color: number): string;
    /**
     * Stores rendering results of a block in the cache.
     *
     * @param key - The key for the rendering results
     * @param group - The rendering results to store
     * @returns The stored rendering results (deep cloned)
     *
     * @example
     * ```typescript
     * const renderedEntity = cache.set(key, entity);
     * ```
     */
    set(key: string, group: AcGiEntity): AcGiEntity;
    /**
     * Gets rendering results with the specified key.
     *
     * @param name - The key of the rendering results
     * @returns The rendering results with the specified key, or undefined if not found
     *
     * @example
     * ```typescript
     * const cachedEntity = cache.get('MyBlock_16711680');
     * if (cachedEntity) {
     *   // Use cached entity
     * }
     * ```
     */
    get(name: string): AcGiEntity | undefined;
    /**
     * Checks if rendering results with the specified key exist in the cache.
     *
     * @param name - The key to check
     * @returns True if the key exists in the cache, false otherwise
     *
     * @example
     * ```typescript
     * if (cache.has('MyBlock_16711680')) {
     *   console.log('Cached result found');
     * }
     * ```
     */
    has(name: string): boolean;
    /**
     * Clears all cached rendering results.
     *
     * @example
     * ```typescript
     * cache.clear();
     * console.log('Cache cleared');
     * ```
     */
    clear(): void;
    /**
     * Draws a block table record and optionally caches the result.
     *
     * This method renders the block table record using the specified renderer
     * and color, and optionally stores the result in the cache for future use.
     *
     * @param renderer - The renderer to use for drawing
     * @param blockTableRecord - The block table record to draw
     * @param color - The color to use for rendering
     * @param cache - Whether to cache the rendering result (default: true)
     * @param transform - Optional transformation matrix to apply
     * @param normal - Optional normal vector
     * @returns The rendered entity
     *
     * @example
     * ```typescript
     * const renderedEntity = cache.draw(
     *   renderer,
     *   blockRecord,
     *   0xFF0000,
     *   true,
     *   transform,
     *   normal
     * );
     * ```
     */
    draw(renderer: AcGiRenderer, blockTableRecord: AcDbBlockTableRecord, color: number, attributes?: AcGiEntity[], cache?: boolean, transform?: AcGeMatrix3d, normal?: AcGeVector3d): AcGiEntity | undefined;
    private addEntity;
    private attachEntityInfo;
}
//# sourceMappingURL=AcDbRenderingCache.d.ts.map