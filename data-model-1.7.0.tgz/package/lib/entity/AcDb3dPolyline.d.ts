import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbOsnapMode } from '../misc';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents the spline-fit type for this 3D polyline.
 */
export declare enum AcDbPoly3dType {
    /**
     * A standard polyline with no spline fitting.
     */
    SimplePoly = 0,
    /**
     * A spline-fit polyline that has a Quadratic B-spline path.
     */
    QuadSplinePoly = 1,
    /**
     * A spline-fit polyline that has a Cubic B-spline path.
     */
    CubicSplinePoly = 2
}
/**
 * Represents a 3d polyline entity in AutoCAD.
 */
export declare class AcDb3dPolyline extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    /** The spline-fit type for this 3D polyline */
    private _polyType;
    /** The underlying geometric polyline object */
    private _geo;
    /**
     * Creates a new empty 2d polyline entity.
     */
    constructor(type: AcDbPoly3dType, vertices: AcGePoint3dLike[], closed?: boolean);
    /**
     * Gets the spline-fit type for this 3D polyline.
     *
     * @returns The spline-fit type for this 3D polyline.
     */
    get polyType(): AcDbPoly3dType;
    /**
     * Sets the spline-fit type for this 3D polyline.
     *
     * @param value - The spline-fit type for this 3D polyline.
     */
    set polyType(value: AcDbPoly3dType);
    /**
     * Gets whether this polyline is closed.
     *
     * A closed polyline has a segment drawn from the last vertex to the first vertex,
     * forming a complete loop.
     *
     * @returns True if the polyline is closed, false otherwise
     *
     * @example
     * ```typescript
     * const isClosed = polyline.closed;
     * console.log(`Polyline is closed: ${isClosed}`);
     * ```
     */
    get closed(): boolean;
    /**
     * Sets whether this polyline is closed.
     *
     * @param value - True to close the polyline, false to open it
     *
     * @example
     * ```typescript
     * polyline.closed = true; // Close the polyline
     * ```
     */
    set closed(value: boolean);
    /**
     * Gets the geometric extents (bounding box) of this polyline.
     *
     * @returns The bounding box that encompasses the entire polyline
     *
     * @example
     * ```typescript
     * const extents = polyline.geometricExtents;
     * console.log(`Polyline bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the grip points for this polyline.
     *
     * Grip points are control points that can be used to modify the polyline.
     * For a polyline, the grip points are all the vertices.
     *
     * @returns Array of grip points (all vertices)
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Gets the object snap points for this polyline.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Returns the full property definition for this polyline entity, including
     * general group and geometry group.
     *
     * The geometry group exposes properties via {@link AcDbPropertyAccessor} so
     * the property palette can update the polyline in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Draws this polyline using the specified renderer.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered polyline entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
}
//# sourceMappingURL=AcDb3dPolyline.d.ts.map