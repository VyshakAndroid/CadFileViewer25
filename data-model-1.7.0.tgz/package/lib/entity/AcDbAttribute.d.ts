import { AcDbMText } from './AcDbMText';
import { AcDbText } from './AcDbText';
/**
 * Represents an attribute entity attached to a block reference (INSERT).
 *
 * An `AcDbAttribute` stores textual data associated with a block reference
 * and is typically created from an attribute definition (ATTDEF) when
 * the block is inserted.
 *
 * This class closely follows the behavior and semantics of
 * `AcDbAttribute` in AutoCAD ObjectARX.
 */
export declare class AcDbAttribute extends AcDbText {
    /** The DXF entity type name. */
    static typeName: string;
    /**
     * Attribute behavior flags.
     * @see AcDbAttributeFlags
     */
    private _flags;
    /**
     * Multi-line attribute flags.
     * @see AcDbAttributeMTextFlag
     */
    private _mtextFlag;
    /** Attribute tag string (identifier). */
    private _tag;
    /**
     * Field length value.
     *
     * This value is preserved for compatibility but is not actively
     * used by AutoCAD.
     */
    private _fieldLength;
    /**
     * Indicates whether the attribute position is locked relative
     * to the block geometry.
     */
    private _lockPositionInBlock;
    /**
     * Indicates whether the attribute is currently locked.
     */
    private _isReallyLocked;
    /**
     * Internal MText representation for multi-line attributes.
     * Undefined for single-line attributes.
     */
    private _mtext?;
    constructor();
    /**
     * Gets whether the attribute is invisible.
     */
    get isInvisible(): boolean;
    /**
     * Sets whether the attribute is invisible.
     */
    set isInvisible(value: boolean);
    /**
     * Gets whether the attribute is constant.
     */
    get isConst(): boolean;
    /**
     * Sets whether the attribute is constant.
     */
    set isConst(value: boolean);
    /**
     * Gets whether the attribute requires verification on input.
     */
    get isVerifiable(): boolean;
    /**
     * Sets whether the attribute requires verification on input.
     */
    set isVerifiable(value: boolean);
    /**
     * Gets whether the attribute has a preset value and does not prompt
     * the user during block insertion.
     */
    get isPreset(): boolean;
    /**
     * Sets whether the attribute has a preset value.
     */
    set isPreset(value: boolean);
    /**
     * Gets whether this attribute is a multi-line (MText-based) attribute.
     */
    get isMTextAttribute(): boolean;
    /**
     * Sets whether this attribute is a multi-line (MText-based) attribute.
     */
    set isMTextAttribute(value: boolean);
    /**
     * Gets whether this attribute is a constant multi-line attribute.
     */
    get isConstMTextAttribute(): boolean;
    /**
     * Sets whether this attribute is a constant multi-line attribute.
     */
    set isConstMTextAttribute(value: boolean);
    /**
     * Gets the attribute tag.
     *
     * The tag uniquely identifies the attribute within a block.
     */
    get tag(): string;
    /**
     * Sets the attribute tag.
     */
    set tag(value: string);
    /**
     * Gets the attribute field length.
     *
     * This value is not currently used by AutoCAD.
     */
    get fieldLength(): number;
    /**
     * Sets the attribute field length.
     */
    set fieldLength(value: number);
    /**
     * Gets whether the attribute position is locked relative to
     * the block geometry.
     */
    get lockPositionInBlock(): boolean;
    /**
     * Sets whether the attribute position is locked relative to
     * the block geometry.
     */
    set lockPositionInBlock(value: boolean);
    /**
     * Gets whether the attribute is currently locked.
     */
    get isReallyLocked(): boolean;
    /**
     * Sets whether the attribute is currently locked.
     */
    set isReallyLocked(value: boolean);
    /**
     * Gets the internal `AcDbMText` used to represent this attribute
     * when it is a multi-line attribute.
     *
     * Returns `undefined` for single-line attributes.
     */
    get mtext(): AcDbMText | undefined;
    /**
     * Sets the internal `AcDbMText` used to represent this attribute
     * as a multi-line attribute.
     *
     * Setting this value automatically marks the attribute as
     * a multi-line attribute.
     */
    set mtext(value: AcDbMText | undefined);
}
//# sourceMappingURL=AcDbAttribute.d.ts.map