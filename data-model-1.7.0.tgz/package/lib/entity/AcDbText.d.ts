import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiRenderer, AcGiTextStyle } from '@mlightcad/graphic-interface';
import { AcDbOsnapMode } from '../misc';
import { AcDbEntity } from './AcDbEntity';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Defines the horizontal alignment mode for text entities.
 */
export declare enum AcDbTextHorizontalMode {
    /** Left-aligned text */
    LEFT = 0,
    /** Center-aligned text */
    CENTER = 1,
    /** Right-aligned text */
    RIGHT = 2,
    /** Aligned text (fits between two points) */
    ALIGNED = 3,
    /** Middle-aligned text */
    MIDDLE = 4,
    /** Fit text (scales to fit between two points) */
    FIT = 5
}
/**
 * Defines the vertical alignment mode for text entities.
 */
export declare enum AcDbTextVerticalMode {
    /** Baseline-aligned text */
    BASELINE = 0,
    /** Bottom-aligned text */
    BOTTOM = 1,
    /** Middle-aligned text */
    MIDDLE = 2,
    /** Top-aligned text */
    TOP = 3
}
/**
 * Represents a text entity in AutoCAD.
 *
 * A text entity is a 2D geometric object that displays text strings in drawings.
 * Text entities can have various properties including position, height, rotation,
 * alignment, and style. Text is always drawn in the plane defined by its normal vector.
 *
 * @example
 * ```typescript
 * // Create a text entity
 * const text = new AcDbText();
 * text.textString = "Hello, World!";
 * text.position = new AcGePoint3d(0, 0, 0);
 * text.height = 2.5;
 * text.horizontalMode = AcDbTextHorizontalMode.CENTER;
 * text.verticalMode = AcDbTextVerticalMode.BASELINE;
 *
 * // Access text properties
 * console.log(`Text: ${text.textString}`);
 * console.log(`Position: ${text.position}`);
 * console.log(`Height: ${text.height}`);
 * ```
 */
export declare class AcDbText extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    /** The text string content */
    private _textString;
    /** The thickness (extrusion) of the text */
    private _thickness;
    /** The height of the text */
    private _height;
    /** The insertion point of the text */
    private _position;
    /** The rotation angle of the text */
    private _rotation;
    /** The oblique angle of the text */
    private _oblique;
    /** The horizontal alignment mode */
    private _horizontalMode;
    /** The vertical alignment mode */
    private _verticalModel;
    /** The text style name */
    private _styleName;
    /** The width factor (scale) of the text */
    private _widthFactor;
    /**
     * Creates a new text entity.
     *
     * This constructor initializes a text entity with default values.
     * The text string is empty, height is 0, and position is at the origin.
     *
     * @example
     * ```typescript
     * const text = new AcDbText();
     * text.textString = "Sample Text";
     * text.position = new AcGePoint3d(10, 20, 0);
     * text.height = 3.0;
     * ```
     */
    constructor();
    /**
     * Gets the text string content of this entity.
     *
     * @returns The text string
     *
     * @example
     * ```typescript
     * const content = text.textString;
     * console.log(`Text content: ${content}`);
     * ```
     */
    get textString(): string;
    /**
     * Sets the text string content of this entity.
     *
     * @param value - The new text string
     *
     * @example
     * ```typescript
     * text.textString = "New text content";
     * ```
     */
    set textString(value: string);
    /**
     * Gets the thickness of the text.
     *
     * The thickness is the text's dimension along its normal vector direction
     * (sometimes called the extrusion direction).
     *
     * @returns The thickness value
     *
     * @example
     * ```typescript
     * const thickness = text.thickness;
     * console.log(`Text thickness: ${thickness}`);
     * ```
     */
    get thickness(): number;
    /**
     * Sets the thickness of the text.
     *
     * @param value - The new thickness value
     *
     * @example
     * ```typescript
     * text.thickness = 2.0;
     * ```
     */
    set thickness(value: number);
    /**
     * Gets the height of the text.
     *
     * The height value is used as a scale factor for both height and width
     * of the text.
     *
     * @returns The height value
     *
     * @example
     * ```typescript
     * const height = text.height;
     * console.log(`Text height: ${height}`);
     * ```
     */
    get height(): number;
    /**
     * Sets the height of the text.
     *
     * @param value - The new height value
     *
     * @example
     * ```typescript
     * text.height = 5.0;
     * ```
     */
    set height(value: number);
    /**
     * Gets the insertion point of the text in WCS coordinates.
     *
     * @returns The insertion point as a 3D point
     *
     * @example
     * ```typescript
     * const position = text.position;
     * console.log(`Text position: ${position.x}, ${position.y}, ${position.z}`);
     * ```
     */
    get position(): AcGePoint3d;
    /**
     * Sets the insertion point of the text in WCS coordinates.
     *
     * @param value - The new insertion point
     *
     * @example
     * ```typescript
     * text.position = new AcGePoint3d(15, 25, 0);
     * ```
     */
    set position(value: AcGePoint3d);
    /**
     * Gets the rotation angle of the text.
     *
     * The rotation angle is relative to the X axis of the text's OCS,
     * with positive angles going counterclockwise when looking down the Z axis
     * toward the origin.
     *
     * @returns The rotation angle in radians
     *
     * @example
     * ```typescript
     * const rotation = text.rotation;
     * console.log(`Text rotation: ${rotation} radians (${rotation * 180 / Math.PI} degrees)`);
     * ```
     */
    get rotation(): number;
    /**
     * Sets the rotation angle of the text.
     *
     * @param value - The new rotation angle in radians
     *
     * @example
     * ```typescript
     * text.rotation = Math.PI / 4; // 45 degrees
     * ```
     */
    set rotation(value: number);
    /**
     * Gets the oblique angle of the text.
     *
     * The oblique angle is the angle from the text's vertical; that is, the top
     * of the text "slants" relative to the bottom, similar to italic text.
     * Positive angles slant characters forward at their tops.
     *
     * @returns The oblique angle in radians
     *
     * @example
     * ```typescript
     * const oblique = text.oblique;
     * console.log(`Text oblique angle: ${oblique} radians`);
     * ```
     */
    get oblique(): number;
    /**
     * Sets the oblique angle of the text.
     *
     * @param value - The new oblique angle in radians
     *
     * @example
     * ```typescript
     * text.oblique = Math.PI / 6; // 30 degrees
     * ```
     */
    set oblique(value: number);
    /**
     * Gets the horizontal alignment mode of the text.
     *
     * @returns The horizontal alignment mode
     *
     * @example
     * ```typescript
     * const horizontalMode = text.horizontalMode;
     * console.log(`Horizontal mode: ${horizontalMode}`);
     * ```
     */
    get horizontalMode(): AcDbTextHorizontalMode;
    /**
     * Sets the horizontal alignment mode of the text.
     *
     * @param value - The new horizontal alignment mode
     *
     * @example
     * ```typescript
     * text.horizontalMode = AcDbTextHorizontalMode.CENTER;
     * ```
     */
    set horizontalMode(value: AcDbTextHorizontalMode);
    /**
     * Gets the vertical alignment mode of the text.
     *
     * @returns The vertical alignment mode
     *
     * @example
     * ```typescript
     * const verticalMode = text.verticalMode;
     * console.log(`Vertical mode: ${verticalMode}`);
     * ```
     */
    get verticalMode(): AcDbTextVerticalMode;
    /**
     * Sets the vertical alignment mode of the text.
     *
     * @param value - The new vertical alignment mode
     *
     * @example
     * ```typescript
     * text.verticalMode = AcDbTextVerticalMode.BASELINE;
     * ```
     */
    set verticalMode(value: AcDbTextVerticalMode);
    /**
     * Gets the style name used by this text entity.
     *
     * @returns The text style name
     *
     * @example
     * ```typescript
     * const styleName = text.styleName;
     * console.log(`Text style: ${styleName}`);
     * ```
     */
    get styleName(): string;
    /**
     * Sets the style name for this text entity.
     *
     * @param value - The new text style name
     *
     * @example
     * ```typescript
     * text.styleName = "Standard";
     * ```
     */
    set styleName(value: string);
    /**
     * Gets the width factor of the text.
     *
     * The width factor is applied to the text's width to allow the width to be
     * adjusted independently of the height. For example, if the widthFactor value
     * is 0.8, then the text is drawn with a width that is 80% of its normal width.
     *
     * @returns The width factor value
     *
     * @example
     * ```typescript
     * const widthFactor = text.widthFactor;
     * console.log(`Width factor: ${widthFactor}`);
     * ```
     */
    get widthFactor(): number;
    /**
     * Sets the width factor of the text.
     *
     * @param value - The new width factor value
     *
     * @example
     * ```typescript
     * text.widthFactor = 0.8; // 80% width
     * ```
     */
    set widthFactor(value: number);
    /**
     * Gets the geometric extents (bounding box) of this text.
     *
     * @returns The bounding box that encompasses the text
     *
     * @example
     * ```typescript
     * const extents = text.geometricExtents;
     * console.log(`Text bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the object snap points for this text.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Returns the full property definition for this text entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the text in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the text style for this text entity.
     *
     * This method retrieves the text style from the text style table.
     * If the specified style is not found, it falls back to the 'STANDARD' style.
     *
     * @returns The text style object
     *
     * @example
     * ```typescript
     * const textStyle = text.getTextStyle();
     * ```
     */
    protected getTextStyle(): AcGiTextStyle;
    /**
     * Draws this text using the specified renderer.
     *
     * This method renders the text as a multiline text entity using the text's
     * current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true.
     * @returns The rendered text entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
}
//# sourceMappingURL=AcDbText.d.ts.map