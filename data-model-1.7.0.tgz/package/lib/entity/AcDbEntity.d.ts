import { AcCmColor, AcCmTransparency } from '@mlightcad/common';
import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d } from '@mlightcad/geometry-engine';
import { AcGiEntity, AcGiLineStyle, AcGiLineWeight, AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbObject } from '../base/AcDbObject';
import { AcDbOsnapMode } from '../misc';
import { AcDbEntityProperties, AcDbEntityPropertyGroup } from './AcDbEntityProperties';
/**
 * Abstract base class for all drawing entities.
 *
 * This class provides the fundamental functionality for all drawing entities,
 * including layer management, color handling, linetype support, visibility,
 * and geometric operations. All specific entity types (lines, circles, text, etc.)
 * inherit from this class.
 *
 * @example
 * ```typescript
 * class MyEntity extends AcDbEntity {
 *   get geometricExtents(): AcGeBox3d {
 *     // Implementation for geometric extents
 *   }
 *
 *   draw(renderer: AcGiRenderer): AcGiEntity | undefined {
 *     // Implementation for drawing
 *   }
 * }
 * ```
 */
export declare abstract class AcDbEntity extends AcDbObject {
    /** The entity type name */
    static typeName: string;
    /** The layer name this entity belongs to */
    private _layer?;
    /** The color of this entity */
    private _color?;
    /** The linetype name for this entity */
    private _lineType;
    /** The line weight for this entity */
    private _lineWeight;
    /** The linetype scale factor for this entity */
    private _linetypeScale;
    /** Whether this entity is visible */
    private _visibility;
    /** The transparency level of this entity (0-1) */
    private _transparency;
    /**
     * Gets the type name of this entity.
     *
     * This method returns the entity type by removing the "AcDb" prefix
     * from the constructor name.
     *
     * @returns The entity type name
     *
     * @example
     * ```typescript
     * const entity = new AcDbLine();
     * console.log(entity.type); // "Line"
     * ```
     */
    get type(): string;
    /**
     * Gets the name of the layer referenced by this entity.
     *
     * @returns The layer name
     *
     * @example
     * ```typescript
     * const layerName = entity.layer;
     * ```
     */
    get layer(): string;
    /**
     * Sets the name of the layer for this entity.
     *
     * @param value - The new layer name
     *
     * @example
     * ```typescript
     * entity.layer = 'MyLayer';
     * ```
     */
    set layer(value: string);
    /**
     * Gets the color information of this entity.
     *
     * @returns The color object for this entity
     *
     * @example
     * ```typescript
     * const color = entity.color;
     * ```
     */
    get color(): AcCmColor;
    /**
     * Sets the color information for this entity.
     *
     * @param value - The new color object
     *
     * @example
     * ```typescript
     * entity.color = new AcCmColor(0xFF0000);
     * ```
     */
    set color(value: AcCmColor);
    /**
     * Gets the RGB color of this entity.
     *
     * This method handles the conversion of color indices (including ByLayer and ByBlock)
     * to actual RGB colors. It resolves layer colors and block colors as needed.
     *
     * @returns The RGB color value as a number
     *
     * @example
     * ```typescript
     * const rgbColor = entity.rgbColor;
     * console.log(`RGB: ${rgbColor.toString(16)}`);
     * ```
     */
    get rgbColor(): number;
    /**
     * Gets the name of the line type referenced by this entity.
     *
     * @returns The linetype name
     *
     * @example
     * ```typescript
     * const lineType = entity.lineType;
     * ```
     */
    get lineType(): string;
    /**
     * Sets the name of the line type for this entity.
     *
     * @param value - The new linetype name
     *
     * @example
     * ```typescript
     * entity.lineType = 'DASHED';
     * ```
     */
    set lineType(value: string);
    /**
     * Gets the line weight used by this entity.
     *
     * @returns The line weight value
     */
    get lineWeight(): AcGiLineWeight;
    /**
     * Sets the line weight for this entity.
     *
     * @param value - The new line weight value
     */
    set lineWeight(value: AcGiLineWeight);
    /**
     * Gets the line type scale factor of this entity.
     *
     * When an entity is first instantiated, its line type scale is initialized
     * to an invalid value. When the entity is added to the database, if a
     * linetype scale has not been specified for the entity, it is set to the
     * database's current line type scale value.
     *
     * @returns The linetype scale factor
     *
     * @example
     * ```typescript
     * const scale = entity.linetypeScale;
     * ```
     */
    get linetypeScale(): number;
    /**
     * Sets the line type scale factor for this entity.
     *
     * @param value - The new linetype scale factor
     *
     * @example
     * ```typescript
     * entity.linetypeScale = 2.0;
     * ```
     */
    set linetypeScale(value: number);
    /**
     * Gets whether this entity is visible.
     *
     * @returns True if the entity is visible, false otherwise
     *
     * @example
     * ```typescript
     * const isVisible = entity.visibility;
     * ```
     */
    get visibility(): boolean;
    /**
     * Sets whether this entity is visible.
     *
     * @param value - True to make the entity visible, false to hide it
     *
     * @example
     * ```typescript
     * entity.visibility = false; // Hide the entity
     * ```
     */
    set visibility(value: boolean);
    /**
     * Gets the transparency level of this entity.
     *
     * @returns The transparency value.
     *
     * @example
     * ```typescript
     * const transparency = entity.transparency;
     * ```
     */
    get transparency(): AcCmTransparency;
    /**
     * Sets the transparency level of this entity.
     *
     * @param value - The transparency value.
     *
     * @example
     * ```typescript
     * entity.transparency = 0.5; // 50% transparent
     * ```
     */
    set transparency(value: AcCmTransparency);
    /**
     * Resolves the effective properties of this entity.
     *
     * This method determines the final, usable values for entity properties such as
     * layer, linetype, lineweight, color, and other display-related attributes.
     * If a property is not explicitly set on the entity (for example, it is undefined
     * or specified as *ByLayer* / *ByBlock*), the value is resolved according to the
     * current AutoCAD system variables and drawing context.
     *
     * Typical system variables involved in the resolution process include, but are
     * not limited to:
     * - `CLAYER`    – Current layer
     * - `CELTYPE`   – Current linetype
     * - `CELWEIGHT` – Current lineweight
     * - `CECOLOR`   – Current color
     *
     * The resolution follows AutoCAD semantics:
     * - Explicitly assigned entity properties take precedence
     * - *ByLayer* properties are inherited from the entity’s layer
     * - *ByBlock* properties are inherited from the owning block reference
     * - If no explicit value can be determined, the corresponding system variable
     *   or default drawing value is used
     *
     * This method does not change user-defined property settings; it only computes
     * and applies the final effective values used for display, selection, and
     * downstream processing.
     */
    resolveEffectiveProperties(): void;
    /**
     * Returns the full property definition for this entity, including
     * all property groups and runtime accessors.
     *
     * This getter is used by the property inspector UI to:
     * - determine the layout and grouping of properties,
     * - look up editable flags and metadata,
     * - read/write live values on this entity using accessors.
     *
     * The returned structure contains:
     * - static metadata (label, type, group structure),
     * - dynamic accessor bindings that expose the actual values stored in the entity.
     *
     * Note: The `groups` array contains `AcDbEntityPropertyGroup` objects whose
     * `properties` entries are runtime-resolved property descriptors that include
     * {@link AcDbPropertyAccessor} objects. Each property object therefore
     * conforms to `AcDbEntityRuntimeProperty`.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this entity.
     *
     * Grip points are the control points that can be used to modify the entity.
     * This method should be overridden by subclasses to provide entity-specific
     * grip points.
     *
     * @returns Array of grip points as 3D points
     *
     * @example
     * ```typescript
     * const gripPoints = entity.subGetGripPoints();
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Gets the object snap points for this entity.
     *
     * Object snap points are the points that can be used for precise positioning
     * when drawing or editing. This method should be overridden by subclasses
     * to provide entity-specific snap points.
     *
     * @param osnapMode - The object snap mode
     * @param pickPoint - The pick point
     * @param lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     * @param gsMark - The object id of subentity. For now, it is used by INSERT
     * entity only. In AutoCAD, it uses AcGiSubEntityTraits::setSelectionMarkerInput
     * to set GS marker of the subentity involved in the object snap operation. For
     * now, we don't provide such a GS marker mechanism yet. So passed id of subentity
     * as GS marker. Maybe this behavior will change in the future.
     *
     * @example
     * ```typescript
     * const snapPoints: AcGePoint3d[] = [];
     * entity.subGetOsnapPoints(AcDbOsnapMode.Endpoint, 0, pickPoint, lastPoint, snapPoints);
     * ```
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[], gsMark?: AcDbObjectId): void;
    /**
     * Transforms this entity by the specified matrix.
     *
     * This method applies a geometric transformation to the entity.
     * Subclasses should override this method to provide entity-specific
     * transformation behavior.
     *
     * @param matrix - The transformation matrix to apply
     * @returns This entity after transformation
     *
     * @example
     * ```typescript
     * const matrix = AcGeMatrix3d.translation(10, 0, 0);
     * entity.transformBy(matrix);
     * ```
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Gets the geometric extents of this entity.
     *
     * This method should be implemented by subclasses to return the
     * bounding box that encompasses the entire entity.
     *
     * @returns The geometric extents as a 3D bounding box
     *
     * @example
     * ```typescript
     * const extents = entity.geometricExtents;
     * console.log(`Min: ${extents.minPoint}, Max: ${extents.maxPoint}`);
     * ```
     */
    abstract get geometricExtents(): AcGeBox3d;
    /**
     * Erase the current entity from the associated database.
     *
     * @returns — true if an entity in the database existed and has been removed,
     * or false if the entity does not exist.
     */
    erase(): boolean;
    /**
     * Draws this entity using the specified renderer.
     *
     * This method should be implemented by subclasses to provide
     * entity-specific drawing behavior.
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true. For now, text and mtext entity supports this flag only. Other types of entities
     * just ignore this flag.
     * @returns The rendered entity, or undefined if drawing failed
     */
    abstract subWorldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Called by cad application when it wants the entity to draw itself in WCS (World Coordinate
     * System) and acts as a wrapper / dispatcher around subWorldDraw(). The children class should
     * never overidde this method.
     *
     * It executes the following logic:
     * - Handles traits (color, linetype, lineweight, transparency, etc.)
     * - Calls subWorldDraw() to do the actual geometry output
     *
     * @param renderer - The renderer to use for drawing
     * @param delay - The flag to delay creating one rendered entity and just create one dummy
     * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
     * is true. For now, text and mtext entity supports this flag only. Other types of entities
     * just ignore this flag.
     * @returns The rendered entity, or undefined if drawing failed
     */
    worldDraw(renderer: AcGiRenderer, delay?: boolean): AcGiEntity | undefined;
    /**
     * Triggers a modified event for this entity.
     *
     * This method notifies listeners that the entity has been modified.
     *
     * @example
     * ```typescript
     * entity.triggerModifiedEvent();
     * ```
     */
    triggerModifiedEvent(): void;
    /**
     * Creates the "General" property group for this entity.
     *
     * This group contains common metadata attributes shared by all CAD entities
     * (e.g., handle, layer). Each property includes a runtime {@link AcDbPropertyAccessor}
     * allowing the property inspector to read and update live values.
     *
     * Subclasses may override this method to append additional general-purpose
     * properties while still preserving this base set.
     *
     * @returns A fully resolved property group containing runtime-accessible properties.
     */
    protected getGeneralProperties(): AcDbEntityPropertyGroup;
    /**
     * Gets the line style for this entity.
     *
     * This method returns the line style based on the entity's linetype
     * and other properties.
     *
     * @returns The line style object
     *
     * @example
     * ```typescript
     * const lineStyle = entity.lineStyle;
     * ```
     */
    get lineStyle(): AcGiLineStyle;
    /**
     * Gets the line type for this entity.
     *
     * This method resolves the line type, handling ByLayer and ByBlock
     * references as needed.
     *
     * @returns The resolved line type
     *
     * @example
     * ```typescript
     * const lineType = entity.getLineType();
     * ```
     */
    private getLineType;
    /**
     * Gets the color of the layer this entity belongs to.
     *
     * This method retrieves the color from the layer table for the
     * layer this entity belongs to.
     *
     * @returns The layer color, or undefined if the layer doesn't exist
     *
     * @example
     * ```typescript
     * const layerColor = entity.getLayerColor();
     * ```
     */
    protected getLayerColor(): AcCmColor | null;
    /**
     * Attaches entity information to a graphic interface entity.
     *
     * This method transfers essential entity properties (object ID, owner ID,
     * layer name, and visibility) from this entity to the target graphic
     * interface entity. This is typically used during the rendering process
     * to ensure the graphic entity has the correct metadata.
     *
     * @param target - The graphic interface entity to attach information to
     *
     */
    private attachEntityInfo;
}
//# sourceMappingURL=AcDbEntity.d.ts.map