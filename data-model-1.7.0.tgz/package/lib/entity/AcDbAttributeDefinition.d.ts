import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbMText } from './AcDbMText';
import { AcDbText } from './AcDbText';
/**
 * Attribute definition flags.
 *
 * These flags control visibility, editability, prompting behavior,
 * and verification requirements of an attribute.
 */
export declare enum AcDbAttributeFlags {
    /** Attribute is invisible (not displayed). */
    Invisible = 1,
    /** Attribute is constant and cannot be modified per block reference. */
    Const = 2,
    /** Attribute requires verification on user input. */
    Verifiable = 4,
    /** Attribute has a preset value and does not prompt during insertion. */
    Preset = 8
}
/**
 * Flags related to multi-line (MText-based) attributes.
 */
export declare enum AcDbAttributeMTextFlag {
    /** Attribute is represented as multi-line text (MText). */
    MultiLine = 2,
    /** Multi-line attribute is constant. */
    ConstMultiLine = 4
}
/**
 * Represents an attribute definition attached to a block definition.
 *
 * This class closely follows the behavior and semantics of
 * `AcDbAttributeDefinition` in AutoCAD ObjectARX.
 */
export declare class AcDbAttributeDefinition extends AcDbText {
    /** The DXF entity type name. */
    static typeName: string;
    /**
     * Attribute behavior flags.
     * @see AcDbAttributeFlags
     */
    private _flags;
    /**
     * Multi-line attribute flags.
     * @see AcDbAttributeMTextFlag
     */
    private _mtextFlag;
    /** Attribute tag string (identifier). */
    private _tag;
    /**
     * Prompt string displayed during block insertion.
     *
     * This value is inherited from the corresponding
     * `AcDbAttributeDefinition` and is used to prompt the user
     * for input when the block is inserted.
     */
    private _prompt;
    /**
     * Field length value.
     *
     * This value is preserved for compatibility but is not actively
     * used by AutoCAD.
     */
    private _fieldLength;
    /**
     * Indicates whether the attribute position is locked relative
     * to the block geometry.
     */
    private _lockPositionInBlock;
    /**
     * Indicates whether the attribute is currently locked.
     */
    private _isReallyLocked;
    /**
     * Internal MText representation for multi-line attributes.
     * Undefined for single-line attributes.
     */
    private _mtext?;
    constructor();
    /**
     * Gets whether the attribute is invisible.
     */
    get isInvisible(): boolean;
    /**
     * Sets whether the attribute is invisible.
     */
    set isInvisible(value: boolean);
    /**
     * Gets the prompt string displayed during block insertion.
     *
     * This prompt is shown to the user when the attribute is created
     * from an attribute definition, unless the attribute is preset.
     */
    get prompt(): string;
    /**
     * Sets the prompt string displayed during block insertion.
     *
     * DXF group code: 3
     */
    set prompt(value: string);
    /**
     * Gets whether the attribute is constant.
     */
    get isConst(): boolean;
    /**
     * Sets whether the attribute is constant.
     */
    set isConst(value: boolean);
    /**
     * Gets whether the attribute requires verification on input.
     */
    get isVerifiable(): boolean;
    /**
     * Sets whether the attribute requires verification on input.
     */
    set isVerifiable(value: boolean);
    /**
     * Gets whether the attribute has a preset value and does not prompt
     * the user during block insertion.
     */
    get isPreset(): boolean;
    /**
     * Sets whether the attribute has a preset value.
     */
    set isPreset(value: boolean);
    /**
     * Gets whether this attribute is a multi-line (MText-based) attribute.
     */
    get isMTextAttribute(): boolean;
    /**
     * Sets whether this attribute is a multi-line (MText-based) attribute.
     */
    set isMTextAttribute(value: boolean);
    /**
     * Gets whether this attribute is a constant multi-line attribute.
     */
    get isConstMTextAttribute(): boolean;
    /**
     * Sets whether this attribute is a constant multi-line attribute.
     */
    set isConstMTextAttribute(value: boolean);
    /**
     * Gets the attribute tag.
     *
     * The tag uniquely identifies the attribute within a block.
     */
    get tag(): string;
    /**
     * Sets the attribute tag.
     */
    set tag(value: string);
    /**
     * Gets the attribute field length.
     *
     * This value is not currently used by AutoCAD.
     */
    get fieldLength(): number;
    /**
     * Sets the attribute field length.
     */
    set fieldLength(value: number);
    /**
     * Gets whether the attribute position is locked relative to
     * the block geometry.
     */
    get lockPositionInBlock(): boolean;
    /**
     * Sets whether the attribute position is locked relative to
     * the block geometry.
     */
    set lockPositionInBlock(value: boolean);
    /**
     * Gets whether the attribute is currently locked.
     */
    get isReallyLocked(): boolean;
    /**
     * Sets whether the attribute is currently locked.
     */
    set isReallyLocked(value: boolean);
    /**
     * Gets the internal `AcDbMText` used to represent this attribute
     * when it is a multi-line attribute.
     *
     * Returns `undefined` for single-line attributes.
     */
    get mtext(): AcDbMText | undefined;
    /**
     * Sets the internal `AcDbMText` used to represent this attribute
     * as a multi-line attribute.
     *
     * Setting this value automatically marks the attribute as
     * a multi-line attribute.
     */
    set mtext(value: AcDbMText | undefined);
    /**
     * Draws nothing for attribute definition.
     *
     * @param renderer - The renderer to use for drawing
     * @returns Always return undefined because of drawing nothing for attribute definition.
     */
    subWorldDraw(_renderer: AcGiRenderer): undefined;
}
//# sourceMappingURL=AcDbAttributeDefinition.d.ts.map