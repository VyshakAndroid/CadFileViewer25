import { AcGeBox3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbCurve } from './AcDbCurve';
/**
 * Defines the annotation type for leader entities.
 */
export declare enum AcDbLeaderAnnotationType {
    /** Multiline text annotation */
    MText = 0,
    /** Feature control frame annotation */
    Fcf = 1,
    /** Block reference annotation */
    BlockReference = 2,
    /** No annotation */
    NoAnnotation = 3
}
/**
 * Represents a leader entity in AutoCAD.
 *
 * A leader is a dimension-like entity that consists of a line or spline with an arrowhead
 * pointing to a specific object or location, and an annotation (text, block, or feature
 * control frame) at the other end. Leaders are controlled by dimension variable settings
 * and dimension styles.
 *
 * @example
 * ```typescript
 * // Create a leader entity
 * const leader = new AcDbLeader();
 * leader.appendVertex(new AcGePoint3d(0, 0, 0));
 * leader.appendVertex(new AcGePoint3d(5, 5, 0));
 * leader.appendVertex(new AcGePoint3d(10, 5, 0));
 * leader.hasArrowHead = true;
 * leader.hasHookLine = true;
 * leader.annoType = AcDbLeaderAnnotationType.MText;
 *
 * // Access leader properties
 * console.log(`Number of vertices: ${leader.numVertices}`);
 * console.log(`Has arrow head: ${leader.hasArrowHead}`);
 * console.log(`Has hook line: ${leader.hasHookLine}`);
 * ```
 */
export declare class AcDbLeader extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    /** Whether this leader is spline-fit */
    private _isSplined;
    /** The spline geometry if this leader is spline-fit */
    private _splineGeo?;
    /** Whether this leader has been updated */
    private _updated;
    /** Whether this leader has an arrowhead */
    private _hasArrowHead;
    /** The vertices of the leader line */
    private _vertices;
    /** The dimension style applied to this leader */
    private _dimensionStyle;
    /** Whether this leader has a hook line */
    private _hasHookLine;
    /** The annotation type for this leader */
    private _annoType;
    /**
     * Creates a new leader entity.
     *
     * This constructor initializes a leader with default values.
     * The leader is not spline-fit, has no arrowhead, no hook line,
     * and no annotation type.
     *
     * @example
     * ```typescript
     * const leader = new AcDbLeader();
     * leader.appendVertex(new AcGePoint3d(0, 0, 0));
     * leader.appendVertex(new AcGePoint3d(5, 5, 0));
     * ```
     */
    constructor();
    /**
     * Gets whether this leader is spline-fit.
     *
     * @returns True if the leader is spline-fit, false otherwise
     *
     * @example
     * ```typescript
     * const isSplined = leader.isSplined;
     * console.log(`Leader is spline-fit: ${isSplined}`);
     * ```
     */
    get isSplined(): boolean;
    /**
     * Sets whether this leader is spline-fit.
     *
     * @param value - True to make the leader spline-fit, false otherwise
     *
     * @example
     * ```typescript
     * leader.isSplined = true;
     * ```
     */
    set isSplined(value: boolean);
    /**
     * Gets whether this leader has an arrowhead.
     *
     * @returns True if the leader has an arrowhead, false otherwise
     *
     * @example
     * ```typescript
     * const hasArrowHead = leader.hasArrowHead;
     * console.log(`Leader has arrowhead: ${hasArrowHead}`);
     * ```
     */
    get hasArrowHead(): boolean;
    /**
     * Sets whether this leader has an arrowhead.
     *
     * @param value - True to enable arrowhead, false to disable
     *
     * @example
     * ```typescript
     * leader.hasArrowHead = true;
     * ```
     */
    set hasArrowHead(value: boolean);
    /**
     * Gets whether this leader has a hook line.
     *
     * The "hookline" is the small horizontal line at the end of the leader line
     * just before the annotation.
     *
     * @returns True if the leader has a hook line, false otherwise
     *
     * @example
     * ```typescript
     * const hasHookLine = leader.hasHookLine;
     * console.log(`Leader has hook line: ${hasHookLine}`);
     * ```
     */
    get hasHookLine(): boolean;
    /**
     * Sets whether this leader has a hook line.
     *
     * @param value - True to enable hook line, false to disable
     *
     * @example
     * ```typescript
     * leader.hasHookLine = true;
     * ```
     */
    set hasHookLine(value: boolean);
    /**
     * Gets the number of vertices in the leader's vertex list.
     *
     * @returns The number of vertices
     *
     * @example
     * ```typescript
     * const numVertices = leader.numVertices;
     * console.log(`Number of vertices: ${numVertices}`);
     * ```
     */
    get numVertices(): number;
    /**
     * Gets the dimension style applied to this leader.
     *
     * @returns The dimension style name
     *
     * @example
     * ```typescript
     * const dimensionStyle = leader.dimensionStyle;
     * console.log(`Dimension style: ${dimensionStyle}`);
     * ```
     */
    get dimensionStyle(): string;
    /**
     * Sets the dimension style applied to this leader.
     *
     * @param value - The new dimension style name
     *
     * @example
     * ```typescript
     * leader.dimensionStyle = "Standard";
     * ```
     */
    set dimensionStyle(value: string);
    /**
     * Gets the leader's annotation type.
     *
     * @returns The annotation type
     *
     * @example
     * ```typescript
     * const annoType = leader.annoType;
     * console.log(`Annotation type: ${annoType}`);
     * ```
     */
    get annoType(): AcDbLeaderAnnotationType;
    /**
     * Sets the leader's annotation type.
     *
     * @param value - The new annotation type
     *
     * @example
     * ```typescript
     * leader.annoType = AcDbLeaderAnnotationType.MText;
     * ```
     */
    set annoType(value: AcDbLeaderAnnotationType);
    /**
     * Appends vertex to the end of the vertex list for this leader. If vertex is not in the plane of the
     * leader, then it will be projected parallel the leader's normal onto the leader's plane and the
     * projection will be appended to the leader's vertex list. If the new vertex is too close to the one
     * next to it (that is, within 1.e-10 for X, Y, and Z), the new vertex will not be appended.
     * @param point Input point (in WCS coordinates) to add to the vertex list
     */
    appendVertex(point: AcGePoint3dLike): void;
    /**
     * Reset the vertex at index to the point point projected (along the plane normal) onto the plane
     * containing the leader. It doesn't reset the vertex if that would cause one of the segments to
     * become zero length (within 1e-10).
     * @param index Input index number (0 based) of the vertex to change
     * @param point Input new point value (in WCS) to use
     */
    setVertexAt(index: number, point: AcGePoint3dLike): void;
    /**
     * Get the point that is the vertex at the location index (0 based) in this leader's vertex array.
     * @param index Input index number (0 based) of the vertex desired
     */
    vertexAt(index: number): void;
    /**
     * @inheritdoc
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * @inheritdoc
     */
    get closed(): boolean;
    set closed(_value: boolean);
    /**
     * @inheritdoc
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
    private get splineGeo();
    private createSplineIfNeeded;
}
//# sourceMappingURL=AcDbLeader.d.ts.map