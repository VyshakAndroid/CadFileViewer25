import { AcGeBox3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbOsnapMode } from '../misc';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents the curve/spline-fit type for one 2d polyline.
 */
export declare enum AcDbPoly2dType {
    /**
     * A standard polyline with no curve/spline fitting.
     */
    SimplePoly = 0,
    /**
     * A polyline that has been curve fit.
     */
    FitCurvePoly = 1,
    /**
     * A spline-fit polyline that has a Quadratic B-spline path.
     */
    QuadSplinePoly = 2,
    /**
     * A spline-fit polyline that has a Cubic B-spline path.
     */
    CubicSplinePoly = 3
}
/**
 * Represents a 2d polyline entity in AutoCAD. This is the older class used to
 * represent 2D polylines in the legacy (DXF/DWG R12 and before) format.
 *
 * Characteristics
 * - Represents 2D polyline entities, typically planar (all vertices lie in a single plane).
 * - Each vertex is an instance of AcDb2dVertex.
 * - Supports bulge values (for arcs between vertices).
 * - Can represent fit curves or spline-fit polylines (via the polyline type flag).
 * - Each vertex can have flags like curve-fit vertex, spline vertex, etc.
 * - Geometry is stored as a linked list of vertex entities (not a single compact structure).
 *
 * Typical use case
 * - Used mainly for backward compatibility and import/export of old drawings.
 */
export declare class AcDb2dPolyline extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    /** The curve/spline-fit type for this 2d polyline */
    private _polyType;
    /** The elevation (Z-coordinate) of the polyline plane */
    private _elevation;
    /** The underlying geometric polyline object */
    private _geo;
    /**
     * Creates a new empty 2d polyline entity.
     */
    constructor(type: AcDbPoly2dType, vertices: AcGePoint3dLike[], elevation?: number, closed?: boolean, _startWidth?: number, _endWidth?: number, bulges?: number[] | null);
    /**
     * Gets the curve/spline-fit type for this 2d polyline.
     *
     * @returns The curve/spline-fit type for this 2d polyline.
     */
    get polyType(): AcDbPoly2dType;
    /**
     * Sets the curve/spline-fit type for this 2d polyline.
     *
     * @param value - The curve/spline-fit type for this 2d polyline.
     */
    set polyType(value: AcDbPoly2dType);
    /**
     * Gets the elevation of this polyline.
     *
     * The elevation is the distance of the polyline's plane from the WCS origin
     * along the Z-axis.
     *
     * @returns The elevation value
     *
     * @example
     * ```typescript
     * const elevation = polyline.elevation;
     * console.log(`Polyline elevation: ${elevation}`);
     * ```
     */
    get elevation(): number;
    /**
     * Sets the elevation of this polyline.
     *
     * @param value - The new elevation value
     *
     * @example
     * ```typescript
     * polyline.elevation = 10;
     * ```
     */
    set elevation(value: number);
    /**
     * Gets whether this polyline is closed.
     *
     * A closed polyline has a segment drawn from the last vertex to the first vertex,
     * forming a complete loop.
     *
     * @returns True if the polyline is closed, false otherwise
     *
     * @example
     * ```typescript
     * const isClosed = polyline.closed;
     * console.log(`Polyline is closed: ${isClosed}`);
     * ```
     */
    get closed(): boolean;
    /**
     * Sets whether this polyline is closed.
     *
     * @param value - True to close the polyline, false to open it
     *
     * @example
     * ```typescript
     * polyline.closed = true; // Close the polyline
     * ```
     */
    set closed(value: boolean);
    /**
     * Gets the geometric extents (bounding box) of this polyline.
     *
     * @returns The bounding box that encompasses the entire polyline
     *
     * @example
     * ```typescript
     * const extents = polyline.geometricExtents;
     * console.log(`Polyline bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the grip points for this polyline.
     *
     * Grip points are control points that can be used to modify the polyline.
     * For a polyline, the grip points are all the vertices.
     *
     * @returns Array of grip points (all vertices)
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Gets the object snap points for this polyline.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Returns the full property definition for this polyline entity, including
     * general group and geometry group.
     *
     * The geometry group exposes properties via {@link AcDbPropertyAccessor} so
     * the property palette can update the polyline in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Draws this polyline using the specified renderer.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered polyline entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
}
//# sourceMappingURL=AcDb2dPolyline.d.ts.map