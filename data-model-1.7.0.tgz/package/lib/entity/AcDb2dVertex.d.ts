import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbOsnapMode } from '../misc';
import { AcDbEntity } from './AcDbEntity';
export declare enum AcDb2dVertexType {
    /**
     * A standard vertex within a 2D polyline.
     */
    Vertex = 0,
    /**
     * A vertex that was automatically generated as the result of a curve-fit operation.
     * This type of vertex can go away or change automatically during subsequent editing
     * operations on the polyline.
     */
    CurveFitVertex = 1,
    /**
     * A vertex that was automatically generated as the result of a spline-fit operation.
     * This type of vertex can go away or change automatically during subsequent editing
     * operations on the polyline.
     */
    SplineFitVertex = 8,
    /**
     * A control point for a spline or curve-fit polyline.
     */
    SplineCtlVertex = 9
}
/**
 * Represents the vertices in 2D polylines.
 */
export declare class AcDb2dVertex extends AcDbEntity {
    /** The entity type name */
    static typeName: string;
    private _position;
    /**
     * The bulge factor used to indicate how much of an arc segment is present at this vertex.
     * The bulge factor is the tangent of one fourth the included angle for an arc segment, made
     * negative if the arc goes clockwise from the start point to the endpoint. A bulge of 0 indicates a
     * straight segment, and a bulge of 1 is a semicircle.
     */
    private _bulge;
    /** The starting width at this vertex */
    private _startWidth;
    /** The ending width at this vertex */
    private _endWidth;
    /** The vertex type */
    private _vertexType;
    /**
     * Creates a new 2d vertex entity.
     */
    constructor();
    /**
     * Gets the position value of the vertex. The position point value must be in OCS coordinates
     * (the OCS of the polyline containing the vertex), not WCS. The Z coordinate is kept in the
     * owning AcDb2dPolyline only for historical purposes.
     *
     * @returns The position value of the vertex
     */
    get position(): AcGePoint3d;
    /**
     * Sets the position value of the vertex. The position point value must be in OCS coordinates
     * (the OCS of the polyline containing the vertex), not WCS. The Z coordinate is kept in the
     * owning AcDb2dPolyline only for historical purposes.
     *
     * @param value - The position value of the vertex
     */
    set position(value: AcGePoint3dLike);
    /**
     * Gets the vertex's bulge value.
     *
     * @returns The vertex's bulge value
     */
    get bulge(): number;
    /**
     * Sets the vertex's bulge value.
     *
     * @param value - The vertex's bulge value
     */
    set bulge(value: number);
    /**
     * Gets the start width for the vertex. The start width is used as the width at this vertex
     * for the polyline segment from this vertex to the next vertex.
     *
     * @returns The start width for the vertex
     */
    get startWidth(): number;
    /**
     * Sets the start width for the vertex. The start width is used as the width at this vertex
     * for the polyline segment from this vertex to the next vertex.
     *
     * @param value - The start width for the vertex
     */
    set startWidth(value: number);
    /**
     * Gets the end width for the vertex. The end width is used as the width at the end of the
     * polyline segment from this vertex to the next vertex.
     *
     * @returns The end width for the vertex
     */
    get endWidth(): number;
    /**
     * Sets the end width for the vertex. The end width is used as the width at the end of the
     * polyline segment from this vertex to the next vertex.
     *
     * @param value - The end width for the vertex
     */
    set endWidth(value: number);
    /**
     * Gets the type of this vertex.
     * @returns The type of this vertex
     */
    get vertexType(): AcDb2dVertexType;
    /**
     * Sets the type of this vertex.
     * @param value - The type of this vertex
     */
    set vertexType(value: AcDb2dVertexType);
    /**
     * Gets the geometric extents (bounding box) of this vertex.
     *
     * @returns The bounding box that encompasses the entire vertex
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets the grip points for this vertex.
     *
     * @returns Array of grip points (center, start point, end point)
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Gets the object snap points for this vertex.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param _osnapMode - The object snap mode
     * @param _pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(_osnapMode: AcDbOsnapMode, _pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this vertex by the specified matrix.
     *
     * @param matrix - The transformation matrix to apply
     * @returns This vertex after transformation
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Draws nothing because it will be drawn by its parent 2d polyline.
     *
     * @param renderer - The renderer to use for drawing
     * @returns undefined
     */
    subWorldDraw(_renderer: AcGiRenderer): undefined;
}
//# sourceMappingURL=AcDb2dVertex.d.ts.map