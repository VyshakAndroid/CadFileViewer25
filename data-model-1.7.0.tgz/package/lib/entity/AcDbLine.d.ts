import { AcGeBox3d, AcGeMatrix3d, AcGePoint3d, AcGePoint3dLike } from '@mlightcad/geometry-engine';
import { AcGiRenderer } from '@mlightcad/graphic-interface';
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode';
import { AcDbCurve } from './AcDbCurve';
import { AcDbEntityProperties } from './AcDbEntityProperties';
/**
 * Represents a line entity in AutoCAD.
 *
 * A line is a 3D geometric object defined by its start point and end point.
 * Lines are fundamental drawing entities that can be used to create straight
 * line segments in 2D or 3D space.
 *
 * @example
 * ```typescript
 * // Create a line from point (0,0,0) to point (10,10,0)
 * const line = new AcDbLine(
 *   new AcGePoint3d(0, 0, 0),
 *   new AcGePoint3d(10, 10, 0)
 * );
 *
 * // Access line properties
 * console.log(`Start point: ${line.startPoint}`);
 * console.log(`End point: ${line.endPoint}`);
 * console.log(`Mid point: ${line.midPoint}`);
 * ```
 */
export declare class AcDbLine extends AcDbCurve {
    /** The entity type name */
    static typeName: string;
    /** The underlying geometric line object */
    private _geo;
    /**
     * Creates a new line entity.
     *
     * This constructor initializes the line object with the specified start and end points.
     * Both points must be in World Coordinate System (WCS) coordinates.
     *
     * @param start - The starting point of the line in WCS coordinates
     * @param end - The ending point of the line in WCS coordinates
     *
     * @example
     * ```typescript
     * const line = new AcDbLine(
     *   new AcGePoint3d(0, 0, 0),
     *   new AcGePoint3d(100, 50, 0)
     * );
     * ```
     */
    constructor(start: AcGePoint3dLike, end: AcGePoint3dLike);
    /**
     * Gets the starting point of this line.
     *
     * @returns The starting point as a 3D point
     *
     * @example
     * ```typescript
     * const startPoint = line.startPoint;
     * console.log(`Line starts at: ${startPoint.x}, ${startPoint.y}, ${startPoint.z}`);
     * ```
     */
    get startPoint(): AcGePoint3d;
    /**
     * Sets the starting point of this line.
     *
     * @param value - The new starting point
     *
     * @example
     * ```typescript
     * line.startPoint = new AcGePoint3d(5, 5, 0);
     * ```
     */
    set startPoint(value: AcGePoint3dLike);
    /**
     * Gets the ending point of this line.
     *
     * @returns The ending point as a 3D point
     *
     * @example
     * ```typescript
     * const endPoint = line.endPoint;
     * console.log(`Line ends at: ${endPoint.x}, ${endPoint.y}, ${endPoint.z}`);
     * ```
     */
    get endPoint(): AcGePoint3d;
    /**
     * Sets the ending point of this line.
     *
     * @param value - The new ending point
     *
     * @example
     * ```typescript
     * line.endPoint = new AcGePoint3d(15, 15, 0);
     * ```
     */
    set endPoint(value: AcGePoint3dLike);
    /**
     * Gets the middle point of this line.
     *
     * The middle point is calculated as the midpoint between the start and end points.
     *
     * @returns The middle point as a 3D point
     *
     * @example
     * ```typescript
     * const midPoint = line.midPoint;
     * console.log(`Line midpoint: ${midPoint.x}, ${midPoint.y}, ${midPoint.z}`);
     * ```
     */
    get midPoint(): AcGePoint3d;
    /**
     * Gets the geometric extents (bounding box) of this line.
     *
     * @returns The bounding box that encompasses the entire line
     *
     * @example
     * ```typescript
     * const extents = line.geometricExtents;
     * console.log(`Line bounds: ${extents.minPoint} to ${extents.maxPoint}`);
     * ```
     */
    get geometricExtents(): AcGeBox3d;
    /**
     * Gets whether this line is closed.
     *
     * Lines are always open entities, so this always returns false.
     *
     * @returns Always false for lines
     */
    get closed(): boolean;
    /**
     * Returns the full property definition for this line entity, including
     * general group and geometry group.
     *
     * The geometry group exposes editable start/end coordinates via
     * {@link AcDbPropertyAccessor} so the property palette can update
     * the line in real-time.
     *
     * Each property is an {@link AcDbEntityRuntimeProperty}.
     */
    get properties(): AcDbEntityProperties;
    /**
     * Gets the grip points for this line.
     *
     * Grip points are control points that can be used to modify the line.
     * For a line, the grip points are the midpoint, start point, and end point.
     *
     * @returns Array of grip points (midpoint, start point, end point)
     *
     * @example
     * ```typescript
     * const gripPoints = line.subGetGripPoints();
     * // gripPoints contains: [midPoint, startPoint, endPoint]
     * ```
     */
    subGetGripPoints(): AcGePoint3d[];
    /**
     * Gets the object snap points for this line.
     *
     * Object snap points are precise points that can be used for positioning
     * when drawing or editing. This method provides snap points based on the
     * specified snap mode.
     *
     * @param osnapMode - The object snap mode
     * @param pickPoint - The point where the user picked
     * @param _lastPoint - The last point
     * @param snapPoints - Array to populate with snap points
     */
    subGetOsnapPoints(osnapMode: AcDbOsnapMode, pickPoint: AcGePoint3dLike, _lastPoint: AcGePoint3dLike, snapPoints: AcGePoint3dLike[]): void;
    /**
     * Transforms this line by the specified matrix.
     *
     * This method applies a geometric transformation to the line, updating
     * both the start and end points according to the transformation matrix.
     *
     * @param matrix - The transformation matrix to apply
     * @returns This line after transformation
     *
     * @example
     * ```typescript
     * const translationMatrix = AcGeMatrix3d.translation(10, 0, 0);
     * line.transformBy(translationMatrix);
     * // Line is now translated 10 units in the X direction
     * ```
     */
    transformBy(matrix: AcGeMatrix3d): this;
    /**
     * Draws this line using the specified renderer.
     *
     * This method renders the line as a series of connected line segments
     * using the line's current style properties.
     *
     * @param renderer - The renderer to use for drawing
     * @returns The rendered line entity, or undefined if drawing failed
     */
    subWorldDraw(renderer: AcGiRenderer): import("@mlightcad/graphic-interface").AcGiEntity;
}
//# sourceMappingURL=AcDbLine.d.ts.map