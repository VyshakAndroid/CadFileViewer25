import { CommonDxfEntity } from '@mlightcad/dxf-json';
import { AcDbEntity } from '../entity';
/**
 * Converts DXF entities to AcDbEntity objects.
 *
 * This class provides functionality to convert various DXF entity types
 * (such as lines, circles, arcs, text, etc.) into their corresponding
 * AcDbEntity objects. It handles the conversion of geometric data,
 * properties, and attributes from DXF format to the internal database format.
 *
 * @example
 * ```typescript
 * const converter = new AcDbEntityConverter();
 * const dxfEntity = { type: 'LINE', startPoint: [0, 0, 0], endPoint: [10, 10, 0] };
 * const acDbEntity = converter.convert(dxfEntity);
 * ```
 */
export declare class AcDbEntityConverter {
    /**
     * Converts a DXF entity to an AcDbEntity.
     *
     * This method takes a DXF entity and converts it to the corresponding
     * AcDbEntity type. It first creates the entity using createEntity(),
     * then processes common attributes using processCommonAttrs().
     *
     * @param entity - The DXF entity to convert
     * @returns The converted AcDbEntity, or null if conversion fails
     *
     * @example
     * ```typescript
     * const dxfLine = { type: 'LINE', startPoint: [0, 0, 0], endPoint: [10, 10, 0] };
     * const acDbLine = converter.convert(dxfLine);
     * if (acDbLine) {
     *   console.log('Converted to:', acDbLine.type);
     * }
     * ```
     */
    convert(entity: CommonDxfEntity): AcDbEntity | null;
    /**
     * Creates the corresponding drawing database entity from DXF format data.
     *
     * This method acts as a factory that routes DXF entities to their specific
     * conversion methods based on the entity type. It handles all supported
     * DXF entity types including geometric entities, text entities, and special entities.
     *
     * @param entity - Input entity data in DXF format
     * @returns The converted drawing database entity, or null if the entity type is not supported
     *
     * @example
     * ```typescript
     * const dxfEntity = { type: 'CIRCLE', center: [0, 0, 0], radius: 5 };
     * const acDbEntity = converter.createEntity(dxfEntity);
     * ```
     */
    private createEntity;
    /**
     * Converts a DXF 3DFACE entity to an AcDbFace.
     *
     * @param face - The DXF 3DFace entity to convert
     * @returns The converted AcDbFace entity
     */
    private convertFace;
    /**
     * Converts a DXF arc entity to an AcDbArc.
     *
     * @param arc - The DXF arc entity to convert
     * @returns The converted AcDbArc entity
     *
     * @example
     * ```typescript
     * const dxfArc = { type: 'ARC', center: [0, 0, 0], radius: 5, startAngle: 0, endAngle: 90 };
     * const acDbArc = converter.convertArc(dxfArc);
     * ```
     */
    private convertArc;
    private convertAttributeCommon;
    private convertAttribute;
    private convertAttributeDefinition;
    /**
     * Converts a DXF circle entity to an AcDbCircle.
     *
     * @param circle - The DXF circle entity to convert
     * @returns The converted AcDbCircle entity
     *
     * @example
     * ```typescript
     * const dxfCircle = { type: 'CIRCLE', center: [0, 0, 0], radius: 5 };
     * const acDbCircle = converter.convertCirle(dxfCircle);
     * ```
     */
    private convertCirle;
    /**
     * Converts a DXF ellipse entity to an AcDbEllipse.
     *
     * @param ellipse - The DXF ellipse entity to convert
     * @returns The converted AcDbEllipse entity
     *
     * @example
     * ```typescript
     * const dxfEllipse = { type: 'ELLIPSE', center: [0, 0, 0], majorAxisEndPoint: [5, 0, 0] };
     * const acDbEllipse = converter.convertEllipse(dxfEllipse);
     * ```
     */
    private convertEllipse;
    private convertLine;
    private convertSpline;
    private convertPoint;
    private convertSolid;
    private convertPolyline;
    private convertLWPolyline;
    private convertHatch;
    private convertTable;
    private convertText;
    private convertMText;
    private convertLeader;
    private convertDimension;
    private processImage;
    private convertImage;
    private processWipeout;
    private convertWipeout;
    private convertViewport;
    private convertRay;
    private convertXline;
    private convertBlockReference;
    private processDimensionCommonAttrs;
    /**
     * Processes common attributes from a DXF entity to an AcDbEntity.
     *
     * This method copies common properties like layer, object ID, owner ID,
     * linetype, lineweight, color, visibility, and transparency from the
     * DXF entity to the corresponding AcDbEntity.
     *
     * @param entity - The source DXF entity
     * @param dbEntity - The target AcDbEntity to populate
     *
     * @example
     * ```typescript
     * converter.processCommonAttrs(dxfEntity, acDbEntity);
     * ```
     */
    private processCommonAttrs;
    /**
     * Converts a number array to an array of 3D points.
     *
     * This utility method takes a flat array of numbers and converts it to
     * an array of AcGePoint3dLike objects. It automatically detects whether
     * the input represents 2D or 3D points based on the array length and
     * number of points.
     *
     * @param numbers - Flat array of numbers representing point coordinates
     * @param numberOfPoints - Expected number of points in the array
     * @returns Array of AcGePoint3dLike objects, or undefined if the conversion fails
     *
     * @example
     * ```typescript
     * const numbers = [0, 0, 10, 10, 20, 20]; // 3 points in 2D
     * const points = converter.numberArrayToPointArray(numbers, 3);
     * // Returns: [{x: 0, y: 0, z: 0}, {x: 10, y: 10, z: 0}, {x: 20, y: 20, z: 0}]
     * ```
     */
    private numberArrayToPointArray;
}
//# sourceMappingURL=AcDbEntitiyConverter.d.ts.map