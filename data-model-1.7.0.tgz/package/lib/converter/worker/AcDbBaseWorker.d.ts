/**
 * Base class for worker scripts that handles all message passing
 * Users only need to implement the executeTask method
 */
export interface AcDbWorkerMessage<TInput = unknown> {
    id: string;
    input: TInput;
}
export interface AcDbWorkerResponse<TOutput = unknown> {
    id: string;
    success: boolean;
    data?: TOutput;
    error?: string;
}
/**
 * Base class for worker scripts
 * Handles all message passing - users only need to implement executeTask
 */
export declare abstract class AcDbBaseWorker<TInput = unknown, TOutput = unknown> {
    constructor();
    /**
     * Set up message handler - called automatically
     */
    private setupMessageHandler;
    /**
     * Send response back to main thread
     */
    private sendResponse;
    /**
     * Execute the actual task - users must implement this
     * @param input - Input data for the task
     * @returns Promise or direct result
     */
    protected abstract executeTask(input: TInput): Promise<TOutput> | TOutput;
}
//# sourceMappingURL=AcDbBaseWorker.d.ts.map