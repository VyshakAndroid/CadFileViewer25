/**
 * Simple worker framework
 */
export interface AcDbWorkerConfig {
    /** Worker script URL (required if useWorker is true) */
    workerUrl: string | URL;
    /** Timeout for worker operations in milliseconds */
    timeout?: number;
    /** Maximum number of concurrent workers */
    maxConcurrentWorkers?: number;
}
export interface AcDbWorkerResult<TOutput = unknown> {
    success: boolean;
    data?: TOutput;
    error?: string;
    duration: number;
}
export interface AcDbWorkerInstance {
    worker: Worker;
    isBusy: boolean;
    id: string;
    createdAt: Date;
}
/**
 * Simple worker framework
 */
export declare class AcDbWorkerManager {
    private config;
    private taskId;
    private workers;
    private pendingTasks;
    constructor(config: AcDbWorkerConfig);
    /**
     * Execute a task with worker support and fallback
     */
    execute<TInput, TOutput>(input: TInput, workerUrl?: string): Promise<AcDbWorkerResult<TOutput>>;
    /**
     * Execute task in web worker
     */
    private executeInWorker;
    /**
     * Clean up a pending task
     */
    private cleanupTask;
    /**
     * Generate unique task ID
     */
    private generateTaskId;
    /**
     * Detect if web workers are supported
     */
    detectWorkerSupport(): boolean;
    /**
     * Get an available worker or create a new one
     */
    private getAvailableWorker;
    /**
     * Release a worker back to the pool
     */
    private releaseWorker;
    /**
     * Generate unique worker ID
     */
    private generateWorkerId;
    /**
     * Get framework statistics
     */
    getStats(): {
        totalWorkers: number;
        busyWorkers: number;
        pendingTasks: number;
        config: Required<AcDbWorkerConfig>;
    };
    /**
     * Clean up all pending tasks and workers
     */
    destroy(): void;
}
/**
 * Simple API for executing tasks with worker support
 */
export declare class AcDbWorkerApi {
    private framework;
    constructor(config: AcDbWorkerConfig);
    /**
     * Execute a task with optional worker support
     */
    execute<TInput, TOutput>(input: TInput, workerUrl?: string): Promise<AcDbWorkerResult<TOutput>>;
    /**
     * Get framework statistics
     */
    getStats(): {
        totalWorkers: number;
        busyWorkers: number;
        pendingTasks: number;
        config: Required<AcDbWorkerConfig>;
    };
    /**
     * Clean up resources
     */
    destroy(): void;
}
/**
 * Create a worker API instance
 */
export declare function createWorkerApi(config: AcDbWorkerConfig): AcDbWorkerApi;
//# sourceMappingURL=AcDbWorkerManager.d.ts.map