import { ParsedDxf } from '@mlightcad/dxf-json';
import { AcDbBaseWorker } from './AcDbBaseWorker';
/**
 * DXF parsing worker
 */
declare class AcDbDxfParserWorker extends AcDbBaseWorker<ArrayBuffer, ParsedDxf> {
    protected executeTask(data: ArrayBuffer): Promise<ParsedDxf>;
}
export declare const dxfParser: AcDbDxfParserWorker;
export {};
//# sourceMappingURL=AcDbDxfParserWorker.d.ts.map