import { ParsedDxf } from '@mlightcad/dxf-json';
import { AcDbDwgVersion } from '../database/AcDbDwgVersion';
/**
 * Extracts DXF version and code page from an ArrayBuffer containing the DXF data.
 * Efficiently reads the data in chunks and stops as soon as both are found
 * or when the HEADER section ends.
 */
export interface AcDbDxfHeaderInfo {
    version: AcDbDwgVersion | null;
    encoding: string | null;
}
/**
 * DXF parsing worker
 */
export declare class AcDbDxfParser {
    parse(data: ArrayBuffer): ParsedDxf;
    /**
     * Reads a DXF ArrayBuffer and returns its version and code page.
     * @param buffer The ArrayBuffer containing DXF file content.
     */
    private getDxfInfoFromBuffer;
}
//# sourceMappingURL=AcDbDxfParser.d.ts.map