type AcDbChunkProcessingCallback = (start: number, end: number) => Promise<void>;
type AcDbChunkProcessingCompleteCallback = () => void | Promise<void>;
/**
 * Class used to break up work into smaller chunks that are executed asynchronously.
 *
 * This is often referred to as "batch processing" or "cooperative multitasking," where the
 * time-consuming task is broken into smaller pieces and executed in small intervals to allow
 * the UI to remain responsive.
 *
 * @example
 * ```typescript
 * const batchProcessor = new AcDbBatchProcessing(1000, 10, 50);
 * await batchProcessor.processChunk(async (start, end) => {
 *   // Process items from start to end
 *   for (let i = start; i < end; i++) {
 *     // Process item i
 *   }
 * });
 * ```
 */
export declare class AcDbBatchProcessing {
    /** Total number of items to process */
    private _count;
    /** Number of chunks to process */
    private _numerOfChunk;
    /** Number of items in one chunk */
    private _chunkSize;
    /** Minimum number of items in one chunk */
    private _minimumChunkSize;
    /**
     * Creates a new AcDbBatchProcessing instance.
     *
     * @param count - The total number of items to process
     * @param numerOfChunk - The number of chunks to process
     * @param minimumChunkSize - The minimum number of items in one chunk. If it is greater
     * than the total number of items to process, the total number is used.
     *
     * @example
     * ```typescript
     * const batchProcessor = new AcDbBatchProcessing(1000, 10, 50);
     * ```
     */
    constructor(count: number, numerOfChunk: number, minimumChunkSize: number);
    /**
     * Gets the total number of items to process.
     *
     * @returns The total number of items to process
     *
     * @example
     * ```typescript
     * const totalItems = batchProcessor.count;
     * ```
     */
    get count(): number;
    /**
     * Gets the number of chunks to process.
     *
     * @returns The number of chunks to process
     *
     * @example
     * ```typescript
     * const numberOfChunks = batchProcessor.numerOfChunk;
     * ```
     */
    get numerOfChunk(): number;
    /**
     * Gets the minimum number of items in one chunk.
     *
     * @returns The minimum number of items in one chunk
     *
     * @example
     * ```typescript
     * const minChunkSize = batchProcessor.minimumChunkSize;
     * ```
     */
    get minimumChunkSize(): number;
    /**
     * Sets the minimum number of items in one chunk.
     *
     * @param value - The new minimum chunk size
     *
     * @example
     * ```typescript
     * batchProcessor.minimumChunkSize = 100;
     * ```
     */
    set minimumChunkSize(value: number);
    /**
     * Gets the number of items in one chunk.
     *
     * @returns The number of items in one chunk
     *
     * @example
     * ```typescript
     * const chunkSize = batchProcessor.chunkSize;
     * ```
     */
    get chunkSize(): number;
    /**
     * Calculates the chunk size based on the total count, number of chunks, and minimum chunk size.
     *
     * @example
     * ```typescript
     * batchProcessor.calculateChunkSize();
     * ```
     */
    private calculateChunkSize;
    /**
     * Schedules a task to be executed asynchronously.
     *
     * This method uses requestAnimationFrame in browser environments or setTimeout
     * in Node.js environments to schedule the task.
     *
     * @param callback - The callback function to schedule
     * @returns Promise that resolves when the task completes
     *
     * @example
     * ```typescript
     * await batchProcessor.scheduleTask(async () => {
     *   // Task to be executed asynchronously
     * });
     * ```
     */
    private scheduleTask;
    /**
     * Processes items in chunks using the provided callback function.
     *
     * This method breaks up the work into chunks and processes each chunk
     * asynchronously, allowing the UI to remain responsive.
     *
     * @param callback - The callback function to execute for each chunk
     * @returns Promise that resolves when all chunks have been processed
     *
     * @example
     * ```typescript
     * await batchProcessor.processChunk(async (start, end) => {
     *   for (let i = start; i < end; i++) {
     *     // Process item i
     *     await processItem(i);
     *   }
     * });
     * ```
     */
    processChunk(callback: AcDbChunkProcessingCallback, onComplete?: AcDbChunkProcessingCompleteCallback): Promise<void>;
}
export {};
//# sourceMappingURL=AcDbBatchProcessing.d.ts.map