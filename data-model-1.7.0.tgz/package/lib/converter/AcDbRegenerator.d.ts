import { AcDbDatabase } from '../database';
import { AcDbConversionProgressCallback, AcDbDatabaseConverter } from '../database/AcDbDatabaseConverter';
/**
 * Database regenerator.
 *
 * This class extends AcDbDatabaseConverter so that it can leverage the existing
 * logic to open one database such as progress notification. However, it doesn't
 * really do any conversion tasks and just pass one database instance and
 * it.
 */
export declare class AcDbRegenerator extends AcDbDatabaseConverter<AcDbDatabase> {
    private _database;
    constructor(db: AcDbDatabase);
    /**
     * Does nothing and always passes the database instance back.
     * @returns The database instance associated with this generator
     *
     */
    protected parse(): Promise<{
        model: AcDbDatabase;
        data: {
            unknownEntityCount: number;
        };
    }>;
    /**
     * Does nothing and always returns one empty array.
     *
     * @returns An empty array
     */
    protected getFonts(): never[];
    /**
     * Processes entities in batches to maintain UI responsiveness.
     *
     * This method breaks up the entity processing work into smaller chunks that are
     * executed asynchronously. This is often referred to as "batch processing" or
     * "cooperative multitasking," where the time-consuming task is broken into
     * smaller pieces and executed in small intervals to allow the UI to remain responsive.
     *
     * @param source - Source database
     * @param target - Target database
     * @param minimumChunkSize - Minimum number of entities to process in each chunk
     * @param startPercentage - Object containing the starting percentage for progress tracking
     * @param progress - Optional callback for progress updates
     */
    protected processEntities(source: AcDbDatabase, target: AcDbDatabase, minimumChunkSize: number, startPercentage: {
        value: number;
    }, progress?: AcDbConversionProgressCallback): Promise<void>;
    /**
     * Processes blocks.
     */
    protected processBlocks(): void;
    /**
     * Processes header variables.
     */
    protected processHeader(): void;
    /**
     * Processes block table records.
     */
    protected processBlockTables(): void;
    /**
     * Processes objects defined in database.
     * ```
     */
    protected processObjects(): void;
    /**
     * Processes viewport table records.
     */
    protected processViewports(): void;
    /**
     * Processes layer table records.
     */
    protected processLayers(): void;
    /**
     * Processes linetype table records.
     */
    protected processLineTypes(): void;
    /**
     * Processes text style table records.
     */
    protected processTextStyles(): void;
    /**
     * Processes text style table records.
     */
    protected processDimStyles(): void;
    /**
     * Groups entities by their `type` property and flattens the result into a single array.
     *
     * The order of `type` groups follows the order in which they first appear in the input array.
     * Items within each group preserve their original order.
     *
     * This runs in O(n) time, which is generally faster than sorting when you
     * don't care about alphabetical order of types.
     *
     * @param entities - The array of entities to group and flatten.
     *
     * @returns A new array of entities grouped by their `type` property.
     */
    private groupAndFlattenByType;
    private triggerEvents;
}
//# sourceMappingURL=AcDbRegenerator.d.ts.map