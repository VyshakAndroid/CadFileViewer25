import { ParsedDxf } from '@mlightcad/dxf-json';
import { AcDbDatabase, AcDbDatabaseConverterConfig } from '../database';
import { AcDbConversionProgressCallback, AcDbDatabaseConverter } from '../database/AcDbDatabaseConverter';
/**
 * Default database converter for DXF files.
 *
 * This class extends AcDbDatabaseConverter to provide specialized functionality
 * for converting DXF (Drawing Exchange Format) files into AcDbDatabase objects.
 * It handles parsing DXF data, processing entities, blocks, tables, and other
 * DXF-specific structures.
 *
 * @example
 * ```typescript
 * const converter = new AcDbDxfConverter();
 * const database = await converter.convert(dxfData);
 * ```
 */
export declare class AcDbDxfConverter extends AcDbDatabaseConverter<ParsedDxf> {
    constructor(config?: AcDbDatabaseConverterConfig);
    /**
     * Parses DXF data into a ParsedDxf object.
     *
     * @param data - The DXF data
     * @returns Parsed DXF object containing all the parsed data
     *
     */
    protected parse(data: ArrayBuffer): Promise<{
        model: ParsedDxf | undefined;
        data: {
            unknownEntityCount: number;
        };
    }>;
    /**
     * Gets all fonts used by entities in model space and paper space.
     *
     * This method analyzes the DXF data to extract all font names used by
     * text entities, MText entities, and insert entities throughout the drawing.
     *
     * @param dxf - Input parsed DXF model
     * @returns Array of font names used in the drawing
     *
     * @example
     * ```typescript
     * const fonts = converter.getFonts(parsedDxf);
     * console.log('Used fonts:', fonts);
     * ```
     */
    protected getFonts(dxf: ParsedDxf): string[];
    /**
     * Iterates through entities in a block to get fonts used by text, MText, and insert entities.
     *
     * This is a helper method that recursively processes entities to extract font information
     * from text-based entities and block references.
     *
     * @param entities - Array of DXF entities to process
     * @param blockMap - Map of block definitions
     * @param styleMap - Map of text styles to font names
     * @param fonts - Set to collect font names
     *
     * @example
     * ```typescript
     * const fonts = new Set<string>();
     * converter.getFontsInBlock(entities, blocks, styleMap, fonts);
     * ```
     */
    private getFontsInBlock;
    /**
     * Processes entities in batches to maintain UI responsiveness.
     *
     * This method breaks up the entity processing work into smaller chunks that are
     * executed asynchronously. This is often referred to as "batch processing" or
     * "cooperative multitasking," where the time-consuming task is broken into
     * smaller pieces and executed in small intervals to allow the UI to remain responsive.
     *
     * @param dxf - Parsed DXF data
     * @param db - Target database to add entities to
     * @param minimumChunkSize - Minimum number of entities to process in each chunk
     * @param startPercentage - Object containing the starting percentage for progress tracking
     * @param progress - Optional callback for progress updates
     *
     * @example
     * ```typescript
     * await converter.processEntities(dxf, database, 100, { value: 0 }, progressCallback);
     * ```
     */
    protected processEntities(dxf: ParsedDxf, db: AcDbDatabase, minimumChunkSize: number, startPercentage: {
        value: number;
    }, progress?: AcDbConversionProgressCallback): Promise<void>;
    /**
     * Processes entities within a specific block.
     *
     * This method handles the conversion and addition of entities to a specific
     * block table record.
     *
     * @param entities - Array of DXF entities to process
     * @param blockTableRecord - The block table record to use
     * @param checkOwner - The flag whether to check the owner of entity is the passed
     * blockTableRecord. If yes, convert it and append it to the block table record.
     * Otherwise, ignore the entity.
     *
     * @example
     * ```typescript
     * await converter.processEntitiesInBlock(entities, blockRecord);
     * ```
     */
    private processEntitiesInBlock;
    /**
     * Processes blocks defined in the DXF file.
     *
     * This method iterates through all blocks in the DXF data and creates
     * corresponding AcDbBlockTableRecord objects in the database.
     *
     * @param model - Parsed DXF model containing block definitions
     * @param db - Target database to add blocks to
     *
     * @example
     * ```typescript
     * converter.processBlocks(parsedDxf, database);
     * ```
     */
    protected processBlocks(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes header variables from the DXF file.
     *
     * This method extracts and sets various header variables such as color settings,
     * angle base, angle direction, units, and point display settings.
     *
     * @param model - Parsed DXF model containing header information
     * @param db - Target database to set header variables on
     *
     * @example
     * ```typescript
     * converter.processHeader(parsedDxf, database);
     * ```
     */
    protected processHeader(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes block table records from the DXF file.
     *
     * This method creates AcDbBlockTableRecord objects for each block record
     * defined in the DXF tables section.
     *
     * @param dxf - Parsed DXF data
     * @param db - Target database to add block table records to
     *
     * @example
     * ```typescript
     * converter.processBlockTables(parsedDxf, database);
     * ```
     */
    protected processBlockTables(dxf: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes objects defined in the DXF file.
     *
     * This method handles the conversion of DXF objects such as layouts and
     * image definitions into their corresponding AcDb objects.
     *
     * @param model - Parsed DXF model containing object definitions
     * @param db - Target database to add objects to
     *
     * @example
     * ```typescript
     * converter.processObjects(parsedDxf, database);
     * ```
     */
    protected processObjects(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes viewport table records from the DXF file.
     *
     * This method creates AcDbViewportTableRecord objects for each viewport
     * defined in the DXF tables section, including their properties like
     * center, corners, snap settings, and grid settings.
     *
     * @param model - Parsed DXF model containing viewport definitions
     * @param db - Target database to add viewport table records to
     *
     * @example
     * ```typescript
     * converter.processViewports(parsedDxf, database);
     * ```
     */
    protected processViewports(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes layer table records from the DXF file.
     *
     * This method creates AcDbLayerTableRecord objects for each layer
     * defined in the DXF tables section, including their properties like
     * color, linetype, lineweight, and visibility settings.
     *
     * @param model - Parsed DXF model containing layer definitions
     * @param db - Target database to add layer table records to
     *
     * @example
     * ```typescript
     * converter.processLayers(parsedDxf, database);
     * ```
     */
    protected processLayers(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes linetype table records from the DXF file.
     *
     * This method creates AcDbLinetypeTableRecord objects for each linetype
     * defined in the DXF tables section.
     *
     * @param model - Parsed DXF model containing linetype definitions
     * @param db - Target database to add linetype table records to
     *
     * @example
     * ```typescript
     * converter.processLineTypes(parsedDxf, database);
     * ```
     */
    protected processLineTypes(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes text style table records from the DXF file.
     *
     * This method creates AcDbTextStyleTableRecord objects for each text style
     * defined in the DXF tables section.
     *
     * @param model - Parsed DXF model containing text style definitions
     * @param db - Target database to add text style table records to
     *
     * @example
     * ```typescript
     * converter.processTextStyles(parsedDxf, database);
     * ```
     */
    protected processTextStyles(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes dimension style table records from the DXF file.
     *
     * This method creates AcDbDimStyleTableRecord objects for each dimension style
     * defined in the DXF tables section, including all dimension-related properties
     * like text positioning, arrow settings, and tolerance settings.
     *
     * @param model - Parsed DXF model containing dimension style definitions
     * @param db - Target database to add dimension style table records to
     *
     * @example
     * ```typescript
     * converter.processDimStyles(parsedDxf, database);
     * ```
     */
    protected processDimStyles(model: ParsedDxf, db: AcDbDatabase): void;
    /**
     * Processes common table entry attributes from DXF data.
     *
     * This helper method sets the common attributes (name, objectId, ownerId)
     * that are shared across all table entries.
     *
     * @param entry - DXF table entry containing the source data
     * @param dbEntry - AcDbSymbolTableRecord to populate with the data
     *
     * @example
     * ```typescript
     * converter.processCommonTableEntryAttrs(dxfEntry, dbRecord);
     * ```
     */
    private processCommonTableEntryAttrs;
    /**
     * Groups entities by their `type` property and flattens the result into a single array.
     *
     * The order of `type` groups follows the order in which they first appear in the input array.
     * Items within each group preserve their original order.
     *
     * This runs in O(n) time, which is generally faster than sorting when you
     * don't care about alphabetical order of types.
     *
     * @param entities - The array of entities to group and flatten.
     *
     * @returns A new array of entities grouped by their `type` property.
     */
    private groupAndFlattenByType;
}
//# sourceMappingURL=AcDbDxfConverter.d.ts.map