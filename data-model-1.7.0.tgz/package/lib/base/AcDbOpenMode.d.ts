/**
 * Object open mode, similar to AcDb::OpenMode.
 */
export declare enum AcDbOpenMode {
    kForRead = "kForRead",
    kForWrite = "kForWrite"
}
//# sourceMappingURL=AcDbOpenMode.d.ts.map