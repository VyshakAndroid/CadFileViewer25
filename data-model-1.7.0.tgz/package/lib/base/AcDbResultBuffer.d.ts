import { AcDbTypedValue } from './AcDbTypedValue';
/**
 * Represents an ordered collection of typed values.
 *
 * @remarks
 * This class corresponds to AutoCAD's ResultBuffer class.
 * It is commonly used to store Xrecord data, XData, and
 * other extensible data structures.
 */
export declare class AcDbResultBuffer implements Iterable<AcDbTypedValue> {
    private readonly _values;
    /**
     * Creates a new result buffer.
     *
     * @param values - Optional initial typed values
     */
    constructor(values?: Iterable<AcDbTypedValue>);
    /**
     * Gets the number of typed values in the buffer.
     */
    get length(): number;
    /**
     * Gets the typed value at the specified index.
     *
     * @param index - Zero-based index
     */
    at(index: number): AcDbTypedValue | undefined;
    /**
     * Adds a typed value to the end of the buffer.
     *
     * @param value - Typed value to add
     */
    add(value: AcDbTypedValue): void;
    /**
     * Adds multiple typed values to the buffer.
     *
     * @param values - Typed values to add
     */
    addRange(values: Iterable<AcDbTypedValue>): void;
    /**
     * Removes all values from the buffer.
     */
    clear(): void;
    /**
     * Returns a shallow copy of the typed values.
     */
    toArray(): AcDbTypedValue[];
    /**
     * Creates a deep copy of this result buffer.
     */
    clone(): AcDbResultBuffer;
    /**
     * Returns an iterator for the typed values.
     */
    [Symbol.iterator](): Iterator<AcDbTypedValue>;
}
//# sourceMappingURL=AcDbResultBuffer.d.ts.map