import { AcDbDatabase } from '../database/AcDbDatabase';
import { AcDbLayoutManager } from '../object/layout/AcDbLayoutManager';
/**
 * Returns the singleton instance of the host application services.
 *
 * This function provides access to the global AcDbHostApplicationServices instance
 * that manages various services for host applications at runtime.
 *
 * @returns The singleton instance of AcDbHostApplicationServices
 * @example
 * ```typescript
 * const services = acdbHostApplicationServices();
 * const database = services.workingDatabase;
 * ```
 */
export declare function acdbHostApplicationServices(): AcDbHostApplicationServices;
/**
 * The AcDbHostApplicationServices class provides various services to host applications at runtime.
 *
 * This class implements the singleton pattern and manages:
 * - Working database reference
 * - Layout manager instance
 * - Other application-wide services
 *
 * @example
 * ```typescript
 * const services = acdbHostApplicationServices();
 * services.workingDatabase = new AcDbDatabase();
 * const layoutManager = services.layoutManager;
 * ```
 */
export declare class AcDbHostApplicationServices {
    /** The current working database instance */
    private _workingDatabase;
    /** The layout manager instance */
    private _layoutManager;
    /** The singleton instance of AcDbHostApplicationServices */
    static instance: AcDbHostApplicationServices;
    /**
     * Private constructor to enforce singleton pattern.
     * Initializes the layout manager.
     */
    private constructor();
    /**
     * Gets the current working database.
     *
     * The working database is the primary database that the application
     * is currently operating on. This must be set before it can be accessed.
     *
     * @returns The current working database
     * @throws {Error} When the working database has not been set
     * @example
     * ```typescript
     * const services = acdbHostApplicationServices();
     * try {
     *   const db = services.workingDatabase;
     *   // Use the database
     * } catch (error) {
     *   console.error('Working database not set');
     * }
     * ```
     */
    get workingDatabase(): AcDbDatabase;
    /**
     * Sets the working database.
     *
     * This method sets the database that will be used as the current working database
     * for the application. This database will be returned by the workingDatabase getter.
     *
     * @param database - The database to make the new working database
     * @example
     * ```typescript
     * const services = acdbHostApplicationServices();
     * const db = new AcDbDatabase();
     * services.workingDatabase = db;
     * ```
     */
    set workingDatabase(database: AcDbDatabase);
    /**
     * Gets the layout manager instance.
     *
     * The layout manager is responsible for managing layout objects in the application.
     * This is a singleton instance that is created when the AcDbHostApplicationServices
     * is instantiated.
     *
     * @returns The layout manager instance
     * @example
     * ```typescript
     * const services = acdbHostApplicationServices();
     * const layoutManager = services.layoutManager;
     * // Use the layout manager
     * ```
     */
    get layoutManager(): AcDbLayoutManager;
}
//# sourceMappingURL=AcDbHostApplicationServices.d.ts.map