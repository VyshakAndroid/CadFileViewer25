/**
 * DXF group codes used by AutoCAD for reading and writing DXF/DWG data.
 *
 * This enum mirrors Autodesk.AutoCAD.DatabaseServices.DxfCode exactly.
 * Values indicate both semantic meaning and expected data type.
 *
 * @remarks
 * - Group codes 0–9: string / symbol data
 * - Group codes 10–59: floating-point values
 * - Group codes 60–79: short integers
 * - Group codes 90–99: 32-bit integers
 * - Group codes 100–107: subclass / control strings
 * - Group codes 300–369: strings / handles
 * - Group codes 370–389: lineweight / plot style
 * - Group codes 400+   : extended data (XData)
 * - Negative values   : internal / structural markers
 */
export declare const enum AcDbDxfCode {
    /** Invalid DXF code */
    Invalid = -9999,
    /** Start of an entity or section */
    Start = 0,
    /** Primary text string */
    Text = 1,
    /** Attribute tag, block name, symbol name */
    AttributeTag = 2,
    BlockName = 2,
    ShapeName = 2,
    SymbolTableName = 2,
    SymbolTableRecordName = 2,
    MlineStyleName = 2,
    /** Attribute prompt, dimension post string, description */
    AttributePrompt = 3,
    Description = 3,
    DimPostString = 3,
    DimStyleName = 3,
    LinetypeProse = 3,
    TextFontFile = 3,
    /** CL shape name, dimension prefix/suffix, text bigfont file */
    CLShapeName = 4,
    DimensionAlternativePrefixSuffix = 4,
    SymbolTableRecordComments = 4,
    TextBigFontFile = 4,
    /** Handle or dimension block name */
    Handle = 5,
    DimensionBlock = 5,
    /** Linetype name or dimension block 1 */
    LinetypeName = 6,
    DimBlk1 = 6,
    /** Text style name or dimension block 2 */
    TextStyleName = 7,
    DimBlk2 = 7,
    /** Layer name */
    LayerName = 8,
    /** CL shape text */
    CLShapeText = 9,
    /** X coordinate (WCS / OCS depending on context) */
    XCoordinate = 10,
    /** Y coordinate */
    YCoordinate = 20,
    /** Z coordinate */
    ZCoordinate = 30,
    /** Real (double precision floating-point) */
    Real = 40,
    TxtSize = 40,
    ViewportHeight = 40,
    /** Angle in degrees */
    Angle = 50,
    ViewportSnapAngle = 50,
    /** Visibility flag */
    Visibility = 60,
    /** 16-bit integer */
    Int16 = 70,
    /** 32-bit integer */
    Int32 = 90,
    /** 64-bit integer */
    Int64 = 160,
    /** 8-bit integer */
    Int8 = 280,
    /** Thickness */
    Thickness = 39,
    /** Elevation */
    Elevation = 38,
    /** Line type scale */
    LinetypeScale = 48,
    /** Dash length or MLine offset */
    DashLength = 49,
    MlineOffset = 49,
    LinetypeElement = 49,
    /** Normal vector components */
    NormalX = 210,
    NormalY = 220,
    NormalZ = 230,
    /** UCS origin */
    UcsOrg = 110,
    /** UCS orientation vectors */
    UcsOrientationX = 111,
    UcsOrientationY = 112,
    /** View parameters */
    ViewHeight = 45,
    ViewWidth = 41,
    ViewLensLength = 42,
    ViewFrontClip = 43,
    ViewBackClip = 44,
    ViewBrightness = 141,
    ViewContrast = 142,
    ViewMode = 71,
    /** Viewport parameters */
    ViewportActive = 68,
    ViewportAspect = 41,
    ViewportGrid = 76,
    ViewportIcon = 74,
    ViewportNumber = 69,
    ViewportSnap = 75,
    ViewportSnapPair = 78,
    ViewportSnapStyle = 77,
    ViewportTwist = 51,
    ViewportVisibility = 67,
    ViewportZoom = 73,
    /** Color values */
    Color = 62,
    ColorRgb = 420,
    ColorName = 430,
    /** Lineweight */
    LineWeight = 370,
    /** Plot style */
    PlotStyleNameType = 380,
    PlotStyleNameId = 390,
    /** Gradient fill parameters */
    GradientObjType = 450,
    GradientAngle = 460,
    GradientName = 470,
    GradientColCount = 453,
    GradientPatType = 451,
    GradientTintType = 452,
    GradientShift = 461,
    GradientColVal = 463,
    GradientTintVal = 462,
    /** Handles and object references */
    SoftPointerId = 330,
    HardPointerId = 340,
    SoftOwnershipId = 350,
    HardOwnershipId = 360,
    ArbitraryHandle = 320,
    /** Extended data (XData) */
    ExtendedDataAsciiString = 1000,
    ExtendedDataRegAppName = 1001,
    ExtendedDataControlString = 1002,
    ExtendedDataLayerName = 1003,
    ExtendedDataBinaryChunk = 1004,
    ExtendedDataHandle = 1005,
    ExtendedDataXCoordinate = 1010,
    ExtendedDataWorldXCoordinate = 1011,
    ExtendedDataWorldXDisp = 1012,
    ExtendedDataWorldXDir = 1013,
    ExtendedDataYCoordinate = 1020,
    ExtendedDataWorldYCoordinate = 1021,
    ExtendedDataWorldYDisp = 1022,
    ExtendedDataWorldYDir = 1023,
    ExtendedDataZCoordinate = 1030,
    ExtendedDataWorldZCoordinate = 1031,
    ExtendedDataWorldZDisp = 1032,
    ExtendedDataWorldZDir = 1033,
    ExtendedDataReal = 1040,
    ExtendedDataDist = 1041,
    ExtendedDataScale = 1042,
    ExtendedDataInteger16 = 1070,
    ExtendedDataInteger32 = 1071,
    /** XData helpers */
    XTextString = 300,
    XReal = 140,
    XInt16 = 170,
    XXInt16 = 270,
    /** Control / structural markers */
    Subclass = 100,
    ControlString = 102,
    EmbeddedObjectStart = 101,
    /** Internal markers */
    End = -1,
    FirstEntityId = -2,
    HeaderId = -2,
    XDataStart = -3,
    Operator = -4,
    PReactors = -5,
    XDictionary = -6
}
//# sourceMappingURL=AcDbDxfCode.d.ts.map